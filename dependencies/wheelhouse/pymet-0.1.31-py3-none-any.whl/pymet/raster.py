import numpy as np
from osgeo import gdal, gdal_array, gdalconst
from osgeo import osr
import math
import os
import tempfile
from joblib import load, dump
import shutil
import gc
import logging
import sys
logger = logging.getLogger(__name__)
gdal.UseExceptions()


class RasterExtent:
    def __init__(self, x_min=33.0, x_max=37.0, y_min=2.0, y_max=-2.0):
        self.x_min = x_min
        self.x_max = x_max
        self.y_min = y_min
        self.y_max = y_max

    def __str__(self):
        return "xmin: {0}, xmax: {1}, ymin: {2}, ymax: {3}".format(str(self.x_min),
                                                                       str(self.x_max),
                                                                       str(self.y_min),
                                                                       str(self.y_max))


class RasterProps:

    """ A class for holding raster properties
    At present this class is only valid for non-rotated rasters with a north-up orientation and square sized pixels
    defined by the E-W pixel size
    """

    def __init__(self,
                 pixel_size=1000.0,
                 pixel_type=np.float64,
                 srs_epsg=4326,
                 no_data_value=0.0,
                 band_count=1,
                 extent_coords=None):

        self._pixel_size = pixel_size
        self._pixel_type = pixel_type
        self._srs_epsg = srs_epsg
        self._no_data_value = no_data_value
        self._band_count = band_count
        self._extent_coords = extent_coords or RasterExtent()

    @property
    def pixel_size(self):  # TODO: also use N-S pixel size
        return self._pixel_size

    @property
    def np_pixel_type(self):
        return self._pixel_type

    @property
    def gdal_pixel_type(self):
        """
        See: https://borealperspectives.wordpress.com/2014/01/16/
        data-type-mapping-when-using-pythongdal-to-write-numpy-arrays-to-geotiff/

        See: http://gdal.org/python/osgeo.gdal_array-module.html#GDALTypeCodeToNumericTypeCode
        """

        return gdal_array.NumericTypeCodeToGDALTypeCode(self._pixel_type)  # requires GDAL > 2.0
        #return gdal.GDT_Float64

    @property
    def srs_epsg_code(self):
        return self._srs_epsg

    @property
    def no_data_value(self):
        return self._no_data_value

    @property
    def band_count(self):
        return self._band_count

    @property
    def extent_coords(self):
        return self._extent_coords  # x_min, x_max, y_min, y_max

    @property
    def num_columns(self):
        return int(math.ceil((self.extent_coords.x_max - self.extent_coords.x_min) / self.pixel_size))

    @property
    def num_rows(self):
        return int(math.ceil((self.extent_coords.y_max - self.extent_coords.y_min) / self.pixel_size))

    @property
    def pixel_to_map_trans(self):
        return self.extent_coords.x_min, self.pixel_size, 0, self.extent_coords.y_max, 0, -self.pixel_size


class Raster:
    """ A raster is a n x 2D array of data geographically located on the Earth. A raster can have multiple bands
    of exactly overlapping pixels. A raster can be represented in memory or can be stored to disc as a
    RasterDataset. It has properties stored in a RasterProps object and the data is accessed via the
    RasterPixels object on each RasterBand object. Uses joblib ndarray to provide an optimized, disc based array that
    can be used in parallel operations """

    def __init__(self, raster_props=None, pixel_data=None):
        self._tmp_folder = None
        self._ndarray_tmp = None

        assert raster_props is not None, 'The RasterProps object cannot be null when creating a Raster'
        self._raster_props = raster_props

        if pixel_data is not None:
            assert(isinstance(pixel_data, np.ndarray))
            self._pixel_data = pixel_data
        else:
            self._pixel_data = np.zeros(shape=(self._raster_props.num_rows,
                                               self._raster_props.num_columns,
                                               self._raster_props.band_count),
                                        dtype=self._raster_props.np_pixel_type)

        # ToDo: implement check that raster props match the pixel_data size

        # Create a temporary folder where the joblib mmap will get stored
        self._tmp_folder = tempfile.mkdtemp()

        self._ndarray_tmp = os.path.join(self._tmp_folder, 'pymet_ndarray.mmap')

        ''' TODO: is there a way to give joblib a mmap object from gdal
        rather than reading whole image into memory? '''

        # Dump the numpy array to a mmap object that can handle parallel processing
        dump(self._pixel_data, self._ndarray_tmp)
        self._pixel_data = load(self._ndarray_tmp, mmap_mode='w+')

    def __del__(self):
        """ Need to make sure any references to pixel_data are deleted before this method is called"""

        logger.debug(str(sys.getrefcount(self._pixel_data)))

        # Joblib cleanup
        try:
            np.allclose(self._pixel_data, self._ndarray_tmp)
        except:
            pass

        del self._pixel_data
        del self._ndarray_tmp

        gc.collect()

        if self._tmp_folder is not None:
            try:
                shutil.rmtree(self._tmp_folder)
            except:
                pass

    @property
    def rast_props(self):
        return self._raster_props

    @property
    def pixel_data(self):
        return self._pixel_data


class RasterStorage:

    def __init__(self, name):
        self._name = name

    @property
    def name(self):
        return self._name

    @property
    def gdal_type(self):
        return ''


class ErdasIMGRasterStorage(RasterStorage):

    def __init__(self, name='', location=''):
        super(ErdasIMGRasterStorage, self).__init__(name)
        self._location = location

    @property
    def location(self):
        return self._location

    @property
    def gdal_type(self):
        return 'HFA'


class RasterDataset(Raster):

    """
    The physical representation of a raster. Currently supported format is Erdas IMAGE. Uses GDAL for reading and
    writing the raster to disc.
    """

    def __init__(self, raster_storage=None):

        # Check that the raster_storage isn't blank
        assert raster_storage is not None, "The RasterStorage object cannot be null when creating a RasterDataset"
        self._rast_storage = raster_storage

        # Open the raster as a gdal dataset
        self._gdal_rast = RasterEngine.open_gdal_raster(raster_storage=raster_storage)
        assert self._gdal_rast is not None, "The chosen gdal raster is either missing or cannot be opened"

        # Create a RasterProps object from the gdal dataset
        self._raster_props = RasterEngine.read_gdal_raster_props(self._gdal_rast)
        assert self._raster_props is not None, "The RasterProps were none"

        # Call the Raster constructor
        super().__init__(raster_props=self._raster_props, pixel_data=self._gdal_rast.ReadAsArray())

    def write_pixel_data(self):
        if len(self._pixel_data.shape) > 2:
            for band in range(self._raster_props.band_count):
                outband = self._gdal_rast.GetRasterBand(band+1)
                outband.WriteArray(self._pixel_data[:, :, band])
                outband.FlushCache()
                outband = None
        else:
            outband = self._gdal_rast.GetRasterBand(1)
            outband.WriteArray(self._pixel_data)
            outband.FlushCache()
            outband = None


class RasterEngine:
    """
    A class with functions for working with rasters
    """

    # Meter to Decimal Degree Conversion
    # Based on an average earth radius of 6367516.477 from WGS84 Datum
    ONE_METER_IN_DD = (180.0 / (6367516.477 * np.pi))

    @staticmethod
    def open_gdal_raster(raster_storage=None):
        gdal_rast = None
        try:
            if type(raster_storage) is ErdasIMGRasterStorage:
                filepath = os.path.join(raster_storage.location, raster_storage.name)
                gdal_rast = gdal.Open(filepath, gdalconst.GA_Update)
        except:
            pass
        finally:
            return gdal_rast

    @staticmethod
    def create_gdal_raster(raster_props=None, raster_storage=None, expansion_factor=1.0):

        # Supported gdal raster types: GTiff, HFA,
        # Supported gdal pixel types: GDT_Float64

        assert raster_props is not None, 'RasterProps object cannot be null when creating a gdal raster dataset'
        assert raster_storage is not None, 'RasterStorage object cannot be null when creating a gdal raster dataset'

        gdal_raster = None
        try:

            # Determine the extent of the input geometry
            x_min, x_max, y_min, y_max = raster_props.extent_coords.x_min, raster_props.extent_coords.x_max, \
                                         raster_props.extent_coords.y_min, raster_props.extent_coords.y_max

            # Determine the envelope wrt to the expansion_factor
            if expansion_factor > 1.0:
                dx = (x_max - x_min) * (expansion_factor - 1.0) / 2.0
                dy = (y_max - y_min) * (expansion_factor - 1.0) / 2.0
                x_min -= dx
                x_max += dx
                y_min -= dy
                y_max += dy
                raster_props.extent_coords.x_min = x_min
                raster_props.extent_coords.x_max = x_max
                raster_props.extent_coords.y_min = y_min
                raster_props.extent_coords.y_max = y_max

            # Create the raster file
            driver = gdal.GetDriverByName(raster_storage.gdal_type)
            outlocation = os.path.join(raster_storage.location, raster_storage.name)

            # ToDo: Tailor the create method to the type of RasterStorage object
            gdal_raster = driver.Create(utf8_path=outlocation,
                                        xsize=raster_props.num_columns,
                                        ysize=raster_props.num_rows,
                                        bands=raster_props.band_count,
                                        eType=raster_props.gdal_pixel_type)

            # Define the affine transform for converting between image coordinates and map
            gdal_raster.SetGeoTransform(raster_props.pixel_to_map_trans)

            # Set the band no data values
            for i in range(raster_props.band_count):
                band = gdal_raster.GetRasterBand(i + 1)
                band.SetNoDataValue(raster_props.no_data_value)

            # Set the output spatial reference
            outRasterSRS = osr.SpatialReference()
            outRasterSRS.ImportFromEPSG(raster_props.srs_epsg_code)
            gdal_raster.SetProjection(outRasterSRS.ExportToWkt())

        except:
          pass

        finally:
            return gdal_raster

    @staticmethod
    def read_gdal_raster_props(gdal_rast=None):

        raster_props = None
        try:

            # Rows/Columns/Bands
            gdal_rast_rows = gdal_rast.RasterYSize
            gdal_rast_columns = gdal_rast.RasterXSize
            gdal_rast_band_count = gdal_rast.RasterCount

            # Build the extent_coords
            gdal_rast_geotrans = gdal_rast.GetGeoTransform()
            gdal_rast_pixelsize = gdal_rast_geotrans[1]
            gdal_rast_origin = (gdal_rast_geotrans[0], gdal_rast_geotrans[3])  # x, y
            gdal_rast_extent = RasterExtent(x_min=gdal_rast_origin[0],
                                            x_max=gdal_rast_origin[0] + gdal_rast_columns * gdal_rast_pixelsize,
                                            y_min=gdal_rast_origin[1] - gdal_rast_rows * gdal_rast_pixelsize,
                                            y_max=gdal_rast_origin[1])

            # DataType - read from first available band
            gdal_rast_pixel_type = gdal_array.GDALTypeCodeToNumericTypeCode(gdal_rast.GetRasterBand(1).DataType)

            # No Data Value - read from the first available band
            gdal_rast_nodata_value = gdal_rast.GetRasterBand(1).GetNoDataValue()

            # Projection information
            """
            See: https://gis.stackexchange.com/questions/7608/shapefile-prj-to-postgis-srid-lookup-table/7615#7615
            """
            gdal_rast_wkt = gdal_rast.GetProjection()
            gdal_rast_srs = osr.SpatialReference()
            gdal_rast_srs.ImportFromWkt(gdal_rast_wkt)
            gdal_rast_epsg = gdal_rast_srs.GetAttrValue('AUTHORITY', 1)
            # gdal_rast_srs.AutoIdentifyEPSG()
            # gdal_rast_epsg = gdal_rast_srs.GetAuthorityCode(None)

            raster_props = RasterProps(pixel_size=gdal_rast_pixelsize,
                                       pixel_type=gdal_rast_pixel_type,
                                       srs_epsg=gdal_rast_epsg,
                                       no_data_value=gdal_rast_nodata_value,
                                       band_count=gdal_rast_band_count,
                                       extent_coords=gdal_rast_extent)
        except:
            pass
        finally:
            return raster_props

    @staticmethod
    def random_image_array(cols, rows):
        return np.array([np.random.random_integers(0, 255, cols) for _ in range(0, rows - 1)])

    # @classmethod
    # def rasterize_vector_data(cls, vector_fn, pixel_size, NoData_value, raster_fn):
    #     # Open the data source and read in the extent
    #
    #     source_ds = ogr.Open(vector_fn)
    #     source_layer = source_ds.GetLayer()
    #     x_min, x_max, y_min, y_max = source_layer.GetExtent()
    #     print(x_min, x_max, y_min, y_max)
    #
    #     # Create the destination data source
    #     x_res = int((x_max - x_min) / pixel_size)
    #     y_res = int((y_max - y_min) / pixel_size)
    #     target_ds = gdal.GetDriverByName('GTiff').Create(raster_fn, x_res, y_res, 1, gdal.GDT_Byte)
    #     target_ds.SetGeoTransform((x_min, pixel_size, 0, y_max, 0, -pixel_size))
    #     band = target_ds.GetRasterBand(1)
    #     band.SetNoDataValue(NoData_value)
    #
    #     # Rasterize
    #     gdal.RasterizeLayer(target_ds, [1], source_layer, burn_values=[1])


