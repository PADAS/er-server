import pymet.base as base
import datetime as dt


class PercentileAreaAnalysisParams(base.AnalysisParams):

    def __init__(self,
                 percentile_levels=None,
                 cutoff=0.0,
                 input_raster=None,
                 output_srs=None):
        self._percentile_levels = percentile_levels
        self._cutoff = cutoff
        self._input_raster = input_raster
        self._output_srs = output_srs

    @property
    def percentile_levels(self):
        return self._percentile_levels

    @property
    def cutoff(self):
        return self._cutoff

    @property
    def input_raster(self):
        return self._input_raster

    @property
    def output_srs(self):
        return self._output_srs


class PercentileAreaAnalysisResults(base.AnalysisResult):

    def __init__(self,
                 desired_percentile=100.0,
                 actual_percentile=100.0,
                 area=0.0,
                 shape=None):

        self._desired_percentile = desired_percentile
        self._actual_percentile = actual_percentile
        self._area = area
        self._shape = shape

    @property
    def desired_percentile(self):
        return self._desired_percentile

    @property
    def actual_percentile(self):
        return self._actual_percentile

    @property
    def area(self):
        return self._area

    @property
    def shape(self):
        return self._shape


class PercentileAreaAnalysis:

    @classmethod
    def calc_percentile_area(cls, analysis_params=None):

        # Create the result object
        result = PercentileAreaAnalysisParams()
        result.analysis_start = dt.datetime.utcnow()

        try:

            assert type(analysis_params) is PercentileAreaAnalysisParams

            # Open the raster
            if analysis_params.input_raster is not None:
                # ToDo
                pass

        except base.PymetException as e:
            result.add_error(e)

        return result

