import logging
import datetime as dt

import numpy as np
import ee


logger = logging.getLogger(__name__)

try:
    ee.Initialize() # Remember to call ee.Initialize() before any of these commands !!!!
except ee.ee_exception.EEException as e:
    logger.exception('Error when initializing Earth Engine module. Have you run \'earthengine authenticate\' in this environment yet?')



# useful stylizations
colourPalettes = {'precipitation': {'palette': ['00FFFF', '0000FF']}, }


# ToDo: Finish temporal code
# def addTimeBand(img):
#     """Add a band to the image with its time_start values (Unix-milliseconds) """
#     return img.addBands(img.metadata('system:time_start'))
#
# def ExtractTrajectoryPointValuesFromImageColl(pnt, imgCollName, bandName, scale=500, days=30):
#     """ A function that will return a time-series of pixel values that fall within the dateRangeWithinMilliSeconds
#      for every image within the imgColl at the given pixel location (tempFeat geometry) and for the given band.
#      The proper way to do this function is to have an input feature collection which gets joined on the image
#      collection and use a Filter to determine the images to select that are within X days of a features fixtime. Then
#      perform the reduction to List. But this also requires defining a days parameter.
#      """
#     if days > 0:
#         start = ee.Date(pnt.get('fixtime')).advance(-1 * days, 'day')
#         end = ee.Date(pnt.get('fixtime')).advance(days, 'day')
#         imgColl = ee.ImageCollection(imgCollName).filterDate(start, end)
#     imgColl = imgColl.select(bandName).map(addTimeBand)
#     result = imgColl.toArray().reduceRegion(ee.Reducer.toList(), pnt.geometry(), scale).getInfo().get('array')[0]
#     return pnt.set({'pixelTimeSeries': result})

def convertMillisecondsToDateTime(unixTime):
    t = dt.datetime.utcfromtimestamp(int(unixTime / 1000))
    return t


def convertDateTimeToMilliseconds(inputTime):
    # Define the UNIX Epoch start date
    epoch = dt.datetime(1970, 1, 1, 0, 0, 0)
    return int((inputTime - epoch).total_seconds() * 1000)


def relocs_to_featurecollection(relocs):
    return ee.FeatureCollection([ee.Feature(ee.Geometry.Point(p.geopoint.longitude, p.geopoint.latitude),
                                            {'fixtime': p.fixtime.replace(tzinfo=None)}) for p in relocs.get_fixes()])


def extract_point_values_from_image(relocs, img_name='', band_name='b1', scale=500.0):

    #Exit if the relocs object is null
    if relocs is None:
        return

    #Build the relocations object into a GEE feature collection
    feat_coll = relocs_to_featurecollection(relocs)

    try:
        img = ee.Image(img_name)

        # dictionary result of the reduction
        result = img.reduceRegion(ee.Reducer.toList(), feat_coll.geometry(), scale).getInfo()
        #print(result)

        if result is not None:
            raw_vals = result.get(band_name)
            if raw_vals is not None:
                return np.mean(raw_vals)
    except:
        return


def ReduceRegionByDatetimes(image_stack,
                            region,
                            region_scale,
                            ee_region_reducer_type,
                            ee_stack_reducer_type,
                            band_name,
                            datetimes=[]):

    """A function to perform a series of image stack reductions on the chosen band
     within the given region and for the given datetime tuples"""

    # Get the GPM dataset
    imgColl = ee.ImageCollection(image_stack).select(band_name).sort('system:time_start', False)

    # Convert the datetime tuples into a feature collection
    featColl = ee.FeatureCollection([ee.Feature(None, {'startDate': x[0], 'endDate': x[1]}) for x in datetimes])

    def mapFunc(feat):
        reduc = imgColl.filterDate(feat.get('startDate'), feat.get('endDate')).reduce(
            ee_stack_reducer_type).reduceRegion(ee_region_reducer_type, region.geometry(), region_scale)
        return feat.set({'reduceVal': reduc})

    return [(convertMillisecondsToDateTime(x.get('properties').get('startDate').get('value')),
             x.get('properties').get('reduceVal').get(band_name + '_' + ee_stack_reducer_type))
            for x in featColl.map(mapFunc).getInfo()['features']]



