import ogr
import osr
import math
import os


def generate_rect_coords(center_coords=None, side_len_km=1.0, output_location='', output_name='sample_sites.shp'):
    """Create rectangle corner coords based on input center point in degrees. Coords are lon/lat pairs"""

    def km_to_degrees(s):
        return (180.0 * s) / (math.pi * 6371.0)

    def rect_from_center(xc, yc, length_km):
        """ Naively generate rectangle corner coordinates based on the side length and center point """
        s = km_to_degrees(length_km / 2)
        p1 = (xc - s, yc + s)
        p2 = (xc + s, yc + s)
        p3 = (xc + s, yc - s)
        p4 = (xc - s, yc - s)
        return (p1, p2, p3, p4)

    # set up the shapefile driver
    driver = ogr.GetDriverByName("ESRI Shapefile")

    # create the data source
    data_source = driver.CreateDataSource(os.path.join(output_location, output_name))

    # create the spatial reference, WGS84
    srs = osr.SpatialReference()
    srs.ImportFromEPSG(4326)

    # create the layer
    layer = data_source.CreateLayer("sites", srs, ogr.wkbPolygon)

    # Create fields
    field_name = ogr.FieldDefn("Name", ogr.OFTString)
    field_name.SetWidth(24)
    layer.CreateField(field_name)

    for i, pnt in enumerate(center_coords):
        try:
            # create the feature
            feature = ogr.Feature(layer.GetLayerDefn())

            # Set the attributes using the values from the delimited text file
            feature.SetField("Name", 'Sample Site ' + str(i))

            # Create ring
            ring = ogr.Geometry(ogr.wkbLinearRing)

            for pt in rect_from_center(xc=pnt[0], yc=pnt[1], length_km=side_len_km):
                ring.AddPoint(pt[0], pt[1])
                #print(pt[0], pt[1])

            poly = ogr.Geometry(ogr.wkbPolygon)
            poly.AddGeometry(ring)

            # Create the point from the Well Known Txt
            shp = ogr.CreateGeometryFromWkt(poly.ExportToWkt())

            # Set the feature geometry using the point
            feature.SetGeometry(shp)

            # Create the feature in the layer (shapefile)
            layer.CreateFeature(feature)

        except:
            print('An error occurred')
            pass