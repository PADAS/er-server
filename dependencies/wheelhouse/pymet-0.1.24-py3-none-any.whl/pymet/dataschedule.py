import datetime

class DataSchedule:
    """A class that defines a schedule for acquiring data"""

    def StartDateTime(self, ):
        pass