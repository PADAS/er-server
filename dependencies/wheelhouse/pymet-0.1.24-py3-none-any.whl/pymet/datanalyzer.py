import pymet as pm

class GPSTrackingDataQualityAnalyzer:
    """Methods for testing the quality of tracking data """

    def __init__(self,trajectory):
        traj = trajectory

    def CheckForDataGaps(self):
        """Function to examine a trajectory for gaps in the data"""
        pass

    def ScheduleAdherence(self, SampleSchedule):
        #Function to compare
        pass

