from pymet import base
import datetime as dt
import math
import numpy as np
from osgeo import gdal
import tempfile
import os
import shutil
from joblib import Parallel, delayed
from joblib import load, dump


class KDEAnalysisParams(base.AnalysisParams):

    def __init__(self,
                 smooth_param=0.0,
                 smooth_method='hRef',
                 max_sd=5.0,
                 prob_dens_cut_off=1E-15,
                 rast_output_params=None):

        self._smooth_param = smooth_param
        self._smooth_method = smooth_method
        self._max_sd = max_sd
        self._prob_dens_cut_off = prob_dens_cut_off
        self._rast_output_params = rast_output_params

    @property
    def smooth_param(self):
        return self._smooth_param

    @smooth_param.setter
    def smooth_param(self, value):
        self._smooth_param = value

    @property
    def smooth_method(self):
        return self._smooth_method

    @property
    def max_sd(self):
        return self._max_sd

    @property
    def prob_dens_cut_off(self):
        return self._prob_dens_cut_off

    @property
    def rast_output_params(self):
        return self._rast_output_params


class KDEAnalysisResult(base.AnalysisResult):

    def __init__(self, out_rast=None):
        self._out_rast = out_rast

    @property
    def out_rast(self):
        return self._out_rast

    @out_rast.setter
    def out_rast(self, value):
        self._out_rast = value


class KDEAnalysis:

    @classmethod
    def calc_kde_range(cls, kde_analysis_params=None, trajectory=None):

        # Create kde_analysis_result object
        kde_analysis_result = KDEAnalysisResult()
        kde_analysis_result.analysis_start = dt.datetime.utcnow()

        try:
            # Test to make sure the calculation parameters are not None and the correct type
            assert type(kde_analysis_params) is KDEAnalysisParams

            # Make sure that the trajectory is not None
            if trajectory is None:
                raise base.PymetException('KDE Analysis Error: Trajectory was None.')

            # Retrieve the Geopandas series for the trajectory
            traj_series = trajectory.relocs.as_geopandas_series()

            # Project to the desired output SRS
            if kde_analysis_params.rast_output_params.srs_epsg_code != 4326:
                traj_series = traj_series.to_crs(epsg=kde_analysis_params.rast_output_params.srs_epsg_code)

            # Retrieve the x,y coordinates of the relocs into a numpy array
            traj_coords = np.array([[i[1].x, i[1].y]for i in traj_series.iteritems()])

            # Try to calculate the smoothing parameter if nothing supplied
            if kde_analysis_params.smooth_param == 0.0:
                if kde_analysis_params.smooth_method == "hRef":
                    kde_analysis_params.smooth_param = \
                        KDEAnalysis.calc_href_smooth_param(x=traj_coords[:, 0], y=traj_coords[:, 1])
                else:
                    raise base.PymetException('KDE Analysis Error: ' +
                                              kde_analysis_params.smooth_method + ' is not supported yet.')

            # Test that the smoothing parameter is not zero
            if kde_analysis_params.smooth_param == 0.0:
                raise base.PymetException('KDE Analysis Error: smoothing parameter is zero.')

            # Define the scaling parameters
            outerScalingConstant = 1.0 / (trajectory.relocs.fix_count *
                                          kde_analysis_params.smooth_param *
                                          kde_analysis_params.smooth_param)

            innerScalingConstant = 1.0 / (2.0 * np.pi)

            # Determine the max distance value
            variance = 2.0 * kde_analysis_params.smooth_param * kde_analysis_params.smooth_param
            maxDist = math.pow(kde_analysis_params.max_sd, 2.0) * variance

            # Determine the envelope of the trajectory
            #env = trajectory.relocs().ogr_geometry().GetEnvelope()
            #x_min, x_max, y_min, y_max = env[0], env[1], env[2], env[3]
            x_min = traj_coords[:, 0].min()
            x_max = traj_coords[:, 0].max()
            y_min = traj_coords[:, 1].min()
            y_max = traj_coords[:, 1].max()

            #Determine the envelope wrt to the expansion_factor
            if kde_analysis_params.rast_output_params.expansion_factor > 1.0:
                dx = (x_max - x_min)*(kde_analysis_params.rast_output_params.expansion_factor - 1.0)/2.0
                dy = (y_max - y_min) * (kde_analysis_params.rast_output_params.expansion_factor - 1.0) / 2.0
                x_min -= dx
                x_max += dx
                y_min -= dy
                y_max += dy

            #Todo: align the origin point to some standard grid (e.g., to milliseconds of lat/lon grid, or to 50 m
            #ticks of UTM grid...

            # Determine the output raster size
            num_columns = math.ceil((x_max - x_min) / kde_analysis_params.rast_output_params.pixel_size)
            num_rows = math.ceil((y_max - y_min) / kde_analysis_params.rast_output_params.pixel_size)
            #print('Columns & Rows:', num_columns, num_rows)

            # Create the output raster file
            driver = gdal.GetDriverByName('HFA') #Use Erdas Imagine img format because Esri can read float64 from it
            output_raster = driver.Create(utf8_path=kde_analysis_params.rast_output_params.out_name,
                                        xsize=num_columns,
                                        ysize=num_rows,
                                        bands=1,
                                        eType=gdal.GDT_Float64)

            # Add the raster to the results object
            kde_analysis_result.out_rast = output_raster

            # Define the affine transform for converting between grid coordinates and map coordinates
            # needed by GDAL
            transform_vals=(x_min, kde_analysis_params.rast_output_params.pixel_size, 0,
                            y_max, 0, -kde_analysis_params.rast_output_params.pixel_size)
            output_raster.SetGeoTransform(transform_vals)

            #Get a hold of the raster output band
            outband = output_raster.GetRasterBand(1)

            # Set the NoData Value on the output band
            outband.SetNoDataValue(kde_analysis_params.rast_output_params.no_data_value)

            #Define the output_raster spatial reference

            output_raster.SetProjection(base.SRS.srs_from_epsg
                                        (kde_analysis_params.rast_output_params.srs_epsg_code).ExportToWkt())

            # Define the affine transform to get grid pixel centroids as geographic coordinates and adjusting
            # the origin by a half pixel to the east and south from the grid origin point
            img_centroids_to_map = np.array(transform_vals).reshape(2, 3)
            img_centroids_to_map[0, 0] = x_min + kde_analysis_params.rast_output_params.pixel_size * 0.5
            img_centroids_to_map[1, 0] = y_max - kde_analysis_params.rast_output_params.pixel_size * 0.5

            # Create a blank grid array
            kdeGridArray = np.zeros(shape=(num_rows, num_columns), dtype=np.float64)

            # Loop over each pixel in the grid, transform the pixel coordinates (row, column) into
            # geographic coordinates (i.e., the centroid of the pixel). For each pixel, loop through the
            # relocation points and add the KDE density contribution to the pixel value.
            # ToDo: parallelize the calculation to run each pixel value independently
            it = np.nditer(kdeGridArray, flags=['multi_index'], op_flags=['readwrite'])
            while not it.finished:
                # Define the grid pixel coords:  [1, Pixel (column), Line (row)]
                pixel_coords = np.array([1, it.multi_index[1], it.multi_index[0]]).reshape(3, 1)

                # Get the current pixel centroid coordinates
                centroid = np.dot(img_centroids_to_map, pixel_coords).flatten()

                # Iterate through each point in the trajectory relocs
                for p in traj_coords:

                    # Determine the distance from the pixel centroid to the relocation point
                    distSq = math.pow(centroid[0]-p[0], 2) + math.pow(centroid[1]-p[1], 2)
                    if distSq <= maxDist:
                        theta = innerScalingConstant * math.exp(-distSq / variance)
                        it[0] += theta

                #Scale using the outerscalingconstant
                it[0] *= outerScalingConstant

                #Loop to the next pixel
                it.iternext()

            #Normalize the grid values
            kdeGridArray = kdeGridArray / kdeGridArray.sum()

            """
            Todo: Mask values less than the probability cut-off? Not sure if I want to port this
            from ArcMET...
            """

            # Write the Grid values to the output raster
            # kdeGridArrayReversed = kdeGridArray[::-1]
            outband.WriteArray(kdeGridArray)
            outband.FlushCache()

        except base.PymetException as e:
            kde_analysis_result.add_error(e)


        #Return the analysis kde_analysis_result
        kde_analysis_result.analysis_end = dt.datetime.utcnow()
        return kde_analysis_result #return results

    @classmethod
    def calc_kde_range_parallel(cls, kde_analysis_params=None, trajectory=None):

        if __name__ != "__main__":

            # Create kde_analysis_result object
            kde_analysis_result = KDEAnalysisResult()
            kde_analysis_result.analysis_start = dt.datetime.utcnow()

            # Create a temporary folder
            folder = tempfile.mkdtemp()

            try:
                # Test to make sure the calculation parameters are not None and the correct type
                assert type(kde_analysis_params) is KDEAnalysisParams

                # Make sure that the trajectory is not None
                if trajectory is None:
                    raise base.PymetException('KDE Analysis Error: Trajectory was None.')

                # Retrieve the Geopandas series for the trajectory
                traj_series = trajectory.relocs.as_geopandas_series()

                # Project to the desired output SRS
                if kde_analysis_params.rast_output_params.srs_epsg_code != 4326:
                    traj_series = traj_series.to_crs(epsg=kde_analysis_params.rast_output_params.srs_epsg_code)

                # Retrieve the x,y coordinates of the relocs into a numpy array
                traj_coords = np.array([[i[1].x, i[1].y] for i in traj_series.iteritems()])

                # Try to calculate the smoothing parameter if nothing supplied
                if kde_analysis_params.smooth_param == 0.0:
                    if kde_analysis_params.smooth_method == "hRef":
                        kde_analysis_params.smooth_param = \
                            cls.calc_href_smooth_param(x=traj_coords[:, 0], y=traj_coords[:, 1])
                    else:
                        raise base.PymetException('KDE Analysis Error: ' +
                                                  kde_analysis_params.smooth_method + ' is not supported yet.')

                # Test that the smoothing parameter is not zero
                if kde_analysis_params.smooth_param == 0.0:
                    raise base.PymetException('KDE Analysis Error: smoothing parameter is zero.')

                # Define the scaling parameters
                outerScalingConstant = 1.0 / (trajectory.relocs.fix_count *
                                              kde_analysis_params.smooth_param *
                                              kde_analysis_params.smooth_param)

                innerScalingConstant = 1.0 / (2.0 * np.pi)

                # Determine the max distance value
                variance = 2.0 * kde_analysis_params.smooth_param * kde_analysis_params.smooth_param
                maxDist = math.pow(kde_analysis_params.max_sd, 2.0) * variance

                # Determine the envelope of the trajectory
                # env = trajectory.relocs().ogr_geometry().GetEnvelope()
                # x_min, x_max, y_min, y_max = env[0], env[1], env[2], env[3]
                (x_min, x_max, y_min, y_max) = trajectory.relocs.ogr_geometry.GetEnvelope()
                x_min = traj_coords[:, 0].min()
                x_max = traj_coords[:, 0].max()
                y_min = traj_coords[:, 1].min()
                y_max = traj_coords[:, 1].max()

                # Determine the envelope wrt to the expansion_factor
                if kde_analysis_params.rast_output_params.expansion_factor > 1.0:
                    dx = (x_max - x_min) * (kde_analysis_params.rast_output_params.expansion_factor - 1.0) / 2.0
                    dy = (y_max - y_min) * (kde_analysis_params.rast_output_params.expansion_factor - 1.0) / 2.0
                    x_min -= dx
                    x_max += dx
                    y_min -= dy
                    y_max += dy

                '''TODO: align the origin point to some standard grid
                 (e.g., to milliseconds of lat/lon grid, or to 50 m
                ticks of UTM grid...'''

                # Determine the output raster size
                num_columns = int(math.ceil((x_max - x_min) / kde_analysis_params.rast_output_params.pixel_size))
                num_rows = int(math.ceil((y_max - y_min) / kde_analysis_params.rast_output_params.pixel_size))
                # print('Columns & Rows:', num_columns, num_rows)

                # Create the output raster file
                # Use Erdas Imagine img format because Esri can read float64 from it
                driver = gdal.GetDriverByName('HFA')
                output_raster = driver.Create(utf8_path=kde_analysis_params.rast_output_params.out_name,
                                              xsize=num_columns,
                                              ysize=num_rows,
                                              bands=1,
                                              eType=gdal.GDT_Float64)

                # Add the raster to the results object
                kde_analysis_result.out_rast = output_raster

                # Define the affine transform for converting between grid coordinates and map coordinates
                # needed by GDAL
                transform_vals = (x_min, kde_analysis_params.rast_output_params.pixel_size, 0,
                                  y_max, 0, -kde_analysis_params.rast_output_params.pixel_size)
                output_raster.SetGeoTransform(transform_vals)

                # Get a hold of the raster output band
                outband = output_raster.GetRasterBand(1)

                # Set the NoData Value on the output band
                outband.SetNoDataValue(kde_analysis_params.rast_output_params.no_data_value)

                # Define the output_raster spatial reference
                output_raster.SetProjection(base.SRS.srs_from_epsg
                                            (kde_analysis_params.rast_output_params.srs_epsg_code).ExportToWkt())

                # Define the affine transform to get grid pixel centroids as geographic coordinates and adjusting
                # the origin by a half pixel to the east and south from the grid origin point
                img_centroids_to_map = np.array(transform_vals).reshape(2, 3)
                img_centroids_to_map[0, 0] = x_min + kde_analysis_params.rast_output_params.pixel_size * 0.5
                img_centroids_to_map[1, 0] = y_max - kde_analysis_params.rast_output_params.pixel_size * 0.5

                # Create a blank grid array
                #raster_ndarray = np.zeros(shape=(num_rows, num_columns), dtype=np.float64)

                traj_coords_tmp = os.path.join(folder, 'traj_coords.mmap')
                raster_ndarray_tmp = os.path.join(folder, 'raster_ndarray.mmap')

                # Pre-allocate a writeable shared memory map as a container for the
                # results of the parallel computation
                # raster_ndarray = np.memmap(raster_ndarray_tmp, dtype=np.float64,
                #                  shape=(num_rows, num_columns), mode='w+')

                raster_ndarray = np.zeros(shape=(num_rows, num_columns), dtype=np.float64)

                dump(raster_ndarray, raster_ndarray_tmp)
                raster_ndarray = load(raster_ndarray_tmp, mmap_mode='w+')
                if len(traj_coords) >= 100000:
                    # Dump the trajectory coordinates to disk to free the memory
                    dump(traj_coords, traj_coords_tmp)

                    # Release the reference on the original in memory array and replace it
                    # by a reference to the memmap array so that the garbage collector can
                    # release the memory before forking. gc.collect() is internally called
                    # in Parallel just before forking.
                    traj_coords = load(traj_coords_tmp, mmap_mode='r')

                # Fork the worker processes to perform computation concurrently
                parameters = ((i, j, raster_ndarray, img_centroids_to_map,
                                                            traj_coords,
                                                            maxDist,
                                                            innerScalingConstant,
                                                            outerScalingConstant,
                                                            variance) for i in range(num_rows)
                                                        for j in range(num_columns))

                Parallel(n_jobs=-1, verbose=8)(delayed(cls.raster_calc)(*p) for p in parameters)

                # Normalize the grid values
                #s = raster_ndarray.sum()
                raster_ndarray = raster_ndarray / raster_ndarray.sum()

                """
                Todo: Mask values less than the probability cut-off? Not sure if I want to port this
                from ArcMET...
                """

                # Write the Grid values to the output raster
                outband.WriteArray(raster_ndarray)
                outband.FlushCache()

                try:
                    np.allclose(raster_ndarray, raster_ndarray_tmp)
                except:
                    pass

            except base.PymetException as e:
                kde_analysis_result.add_error(e)
            finally:
                try:
                    shutil.rmtree(folder)
                except:
                    print("Failed to delete: " + folder)

            # Return the analysis kde_analysis_result
            kde_analysis_result.analysis_end = dt.datetime.utcnow()
            return kde_analysis_result  # return results

    @classmethod
    def calc_href_smooth_param(cls, x=None, y=None):
        if x is None:
            return
        if y is None:
            return
        varX = x.var()
        varY = y.var()
        var = math.sqrt(0.5 * (varX + varY))
        t = math.pow(len(x), -1.0 / 6.0)
        hRef = var * t # Source: Worton_1989
        return hRef

    @classmethod
    def raster_calc(cls, i=0, j=0, raster_ndarray=None, img_centroids_to_map=None, traj_coords=None,
                    max_dist=None, inner_scaling_constant=None, outer_scaling_constant=None, variance=None):
        """
        Loop over each pixel in the grid, transform the pixel coordinates (row, column) into
        geographic coordinates (i.e., the centroid of the pixel). For each pixel, loop through the
        relocation points and add the KDE density contribution to the pixel value.
        """

        # # Define the grid pixel coords:  [1, Pixel (column), Line (row)]
        pixel_coords = np.array([1, j, i]).reshape(3, 1)

        # Get the current pixel centroid coordinates
        centroid = np.dot(img_centroids_to_map, pixel_coords).flatten()

        coordinate_distances = np.subtract(traj_coords[:, 0], centroid[0]) ** 2\
                               + np.subtract(traj_coords[:, 1], centroid[1]) ** 2

        # Set flag for elements that meet out max-dist criteria.
        # ...and then eliminate the distances outside that threshold
        low_v = coordinate_distances <= max_dist
        coordinate_distances = coordinate_distances[low_v]

        # Create exponents from distance values.
        coordinate_distances = coordinate_distances * -1 / variance

        # Exp.
        coordinate_distances = np.exp(coordinate_distances)

        # Scalar sum of array.
        theta_accumulator = np.sum(coordinate_distances)

        # Set value in shared array (with scaling constant).
        raster_ndarray.itemset((i,j), raster_ndarray[i,j] + theta_accumulator * outer_scaling_constant)







