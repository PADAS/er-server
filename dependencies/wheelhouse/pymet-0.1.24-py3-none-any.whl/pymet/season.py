import pymet.eetools as eetools
import ee
import sklearn.mixture as gauss
import pandas as pd
import datetime as dt
import logging
from scipy.stats import norm
import numpy as np

logger = logging.getLogger(__name__)


class Season:

    def __init__(self, start=None, end=None, img_col='MODIS/MCD43A4_NDVI', band='NDVI'):
        self._start = start or dt.datetime.utcnow() + dt.timedelta(days=-365)
        self._end = end or dt.datetime.utcnow()
        self._img_coll = img_col
        self._band = band

    def extract_seasonal_vals(self, ee_geo=None, scale=500):
        """
        :param ee_geo: ee_geo is an EE Geometry type
        :param scale:
        :return:
        """

        # get the image stack
        img_coll = ee.ImageCollection(self._img_coll).select(self._band). \
            filterBounds(ee_geo).filter(ee.Filter.date(self._start, self._end)).sort('system:time_start', False)

        # extract the pixel values falling within the region and for the given dates
        ee_result = eetools.extract_img_coll_pixel_values(img_coll, region_geometry=ee_geo, scale=scale)
        img_vals = pd.DataFrame([[x[0], eetools.convertUnixTimeToDateTime(x[1])] for y in ee_result.get('array')
                                 for x in y], columns=['img_val', 'img_date'])

        self._img_vals = img_vals
        return self._img_vals

    def determine_seasons(self, n=2):

        if self._img_vals is not None:
            distr = gauss.GaussianMixture(n_components=n, max_iter=500)
            vals = self._img_vals['img_val'].values.reshape(-1, 1)
            distr.fit(vals)
            mu_vars = sorted(zip(distr.means_.flatten(), distr.covariances_.flatten()), key=lambda x: x[0])
            # print('mu_vars', mu_vars)
            cuts = []
            x = np.linspace(0, 1.0, 1000)
            for i in range(1, len(mu_vars)):
                cuts.append(np.max(x[[norm.sf(x, loc=mu_vars[i-1][0], scale=np.sqrt(mu_vars[i-1][1])) >
                norm.cdf(x, loc=mu_vars[i][0], scale=np.sqrt(mu_vars[i][1]))]]))

            return cuts

        else:
            logger.exception('Could not run EM algorithm on null img_vals array.')

