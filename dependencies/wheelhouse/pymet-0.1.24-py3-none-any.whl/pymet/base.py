from geographiclib.geodesic import Geodesic
from osgeo import ogr
from osgeo import osr
from osgeo import gdal
import numpy as np
import geopandas as gpd
import pandas as pd
import shapely.geometry as shp
import datetime as dt
import uuid


class SRS:

    @classmethod
    def WGS84(cls):
        srs = osr.SpatialReference()
        srs.ImportFromEPSG(4326)
        return srs

    @classmethod
    def srs_from_epsg(cls, epsg=4326):
        srs = osr.SpatialReference()
        srs.ImportFromEPSG(epsg)
        return srs


class GeoPoint:
    """A geographic point is the most basic geometry"""

    def __init__(self, x=0, y=0, z=0):
        """Create a new point with the supplied geographic coordinates.
        Defaults to WGS84 SRS """

        self._point = ogr.Geometry(type=ogr.wkbPoint)
        self._srs_epsg_code = 4326
        self._srs = SRS.WGS84()
        self._point.AddPoint(x, y, z)
        self._point.AssignSpatialReference(self._srs)

    @property
    def longitude(self):
        """Shortcut to getting the X value"""
        return self._point.GetX()

    @property
    def latitude(self):
        """Shortcut to getting the Y value"""
        return self._point.GetY()

    @property
    def ogr_geometry(self):
        """ Return the ogr point """
        return self._point

    @property
    def srs_epsg_code(self):
        """Return the spatial reference system EPSG code"""
        return self._srs_epsg_code

    def dist_to_point(self, point):
        """Returns the distance in meters from this point to another ogr point geometry"""
        if isinstance(point, (GeoPoint, Fix)):
            point = point.ogr_geometry
        elif hasattr(point, "GetX") and hasattr(point, "GetY"):
            pass # looks like a Point object
        else:
            raise ValueError(f'point argument must be of type GeoPoint, Fix or Point.')

        geod = Geodesic.WGS84
        great_circle = geod.Inverse(lat1=self.ogr_geometry.GetY(),
                                    lon1=self.ogr_geometry.GetX(),
                                    lat2=point.GetY(),
                                    lon2=point.GetX())
        return great_circle['s12']

    def __str__(self):
        return str(self.ogr_geometry)


class Fix:
    """A Fix is a temporal geopoint"""

    def __init__(self, geopoint=None, fixtime=None, junk_status=False, guid=None):
        self._fixtime = fixtime
        self._geopoint = geopoint
        self._junk_status = junk_status #Holds a boolean value to indicate whether this point is junk or not
        self._uuid = guid or str(uuid.uuid4().hex)

    @property
    def fixtime(self):
        """ Return the fixtime"""
        return self._fixtime

    @property
    def geopoint(self):
        """Return the geopoint"""
        return self._geopoint

    @property
    def ogr_geometry(self):
        """A shortcut for returning the ogr point geometry from the geopoint"""
        if self._geopoint is not None:
            return self._geopoint.ogr_geometry

    @property
    def junk_status(self):
        return self._junk_status

    @junk_status.setter
    def junk_status(self, value):
        assert type(value) is bool
        self._junk_status = value

    @property
    def uuid(self):
        return self._uuid


class RelocsCoordinateFilter:
    """Filter parameters for filtering get_fixes based on X/Y coordinate ranges or specific coordinate values"""

    def __init__(self, min_x=-180, max_x=180, min_y=-90, max_y=90, filter_point_coords=None):
        self._minX = min_x
        self._maxX = max_x
        self._minY = min_y
        self._maxY = max_y
        self._filter_point_coords = filter_point_coords or [[0, 0]]

    @property
    def max_x(self):
        return self._maxX

    @property
    def min_x(self):
        return self._minX

    @property
    def max_y(self):
        return self._maxY

    @property
    def min_y(self):
        return self._minY

    @property
    def filter_point_coords(self):
        return self._filter_point_coords


class RelocsDateRangeFilter:
    """Filter parameters for filtering based on a datetime range"""

    def __init__(self, start=None, end=None):
        self._start = start
        self._end = end

    @property
    def start(self):
        return self._start

    @property
    def end(self):
        return self._end


class RelocsSpeedFilter:
    """Filter parameters for filtering based on the speed needed to move from one fix to the next"""

    def __init__(self, max_speed_kmhr=float("inf"), temporal_order='ASC'):
        self._max_speed_kmhr = max_speed_kmhr
        self._temporal_order = temporal_order

    @property
    def max_speed_kmhr(self):
        "the threshold speed value in Km/Hr"
        return self._max_speed_kmhr

    @property
    def temporal_order(self):
        "Used to decide in what order the speed filter should be applied - older to newer or newer to older"
        return self._temporal_order


class RelocsDistFilter:
    """Filter parameters for filtering based on the distance needed to move from one fix to the next"""

    def __init__(self, max_dist_km=float("inf"), temporal_order='ASC'):
        self._max_dist_km = max_dist_km
        self._temporal_order = temporal_order

    @property
    def max_dist_km(self):
        """the threshold distance in Km"""
        return self._max_dist_km

    @property
    def temporal_order(self):
        """"Used to decide in what order the distance filter should be applied - older to newer or newer to older"""
        return self._temporal_order


class Relocations:

    """Relocations is a model for a set of get_fixes from a given subject.
    Because get_fixes are temporal, they can be ordered asc or desc"""

    # TODO: Net Square Displacement
    # TODO: Correlated Random Walk from start fix
    # TODO: Biased Random Walk from start fix
    # TODO: Centroid as the harmonic mean of coordinates (see Avagar et al. 2012)

    def __init__(self, fixes=None, subject_id=''):
        self._fixes = fixes or []
        self._subject_id = subject_id

    @property
    def timespan_seconds(self):
        """Returns the total time between start and end times in seconds"""

        if len(self.get_fixes()) > 0:
            earliest_fixtime = self.earliest_fix.fixtime
            latest_fixtime = self.latest_fix.fixtime

            if (earliest_fixtime is not None) and (latest_fixtime is not None):
                ts = latest_fixtime - earliest_fixtime
                return ts.total_seconds()
        else:
            return 0

    @property
    def subject_id(self):
        return self._subject_id

    @property
    def displacement_segment(self):
        """Return the straight line segment between the earliest and latest fix in the get_fixes array """

        if (self.earliest_fix is not None) and (self.latest_fix is not None):
            return StraightTrackSeg(self.earliest_fix, self.latest_fix)
        else:
            return None

    @property
    def fix_count(self):
        """ get_fixes array length"""
        return len(self.get_fixes())

    @property
    def earliest_fix(self):
        """ Return the earliest fix from the get_fixes array"""
        _tmp_list = self.get_fixes()
        if len(_tmp_list) > 0:
            return _tmp_list[0]
        else:
            return None

    @property
    def latest_fix(self):
        """ Return the latest fix from the get_fixes array"""
        _tmp_list = self.get_fixes()
        if len(_tmp_list) > 0:
            return _tmp_list[-1]
        else:
            return None

    @property
    def ogr_geometry(self):
        """Return the ogr multipoint geometry of the relocation get_fixes"""
        _pnts = ogr.Geometry(type=ogr.wkbMultiPoint)
        _pnts.AssignSpatialReference(SRS.WGS84())
        for pnt in self.get_fixes():
            _pnts.AddGeometry(pnt.ogr_geometry)
        return _pnts

    @property
    def centroid(self):
        """ Return the centroid of the get_fixes() array"""

        centroid = self.ogr_geometry.Centroid()
        centroid.AssignSpatialReference(SRS.WGS84())
        return centroid

    def sort_fixes(self, temporal_order='ASC'):
        if temporal_order == 'ASC':
            self._fixes.sort(key=lambda fix: fix.fixtime)
        else:
            self._fixes.sort(key=lambda fix: fix.fixtime, reverse=True)

    def get_fixes(self, temporal_order='ASC', filtered=True):
        """Instance method to access the get_fixes array sorted in either chronologically asc or desc order"""

        if self._fixes:
            if temporal_order == 'DESC':
                if filtered is True:
                    return sorted([f for f in self._fixes if f.junk_status is False],
                                  key=lambda fix: fix.fixtime,
                                  reverse=True)
                else:
                    return sorted(self._fixes,
                                  key=lambda fix: fix.fixtime,
                                  reverse=True)
            else:
                if filtered is True:
                    return sorted([f for f in self._fixes if f.junk_status is False],
                                  key=lambda fix: fix.fixtime)
                else:
                    return sorted(self._fixes,
                                  key=lambda fix: fix.fixtime)
        else:
            return []

    def as_geopandas_series(self, temporal_order='ASC'):
        """Method to access the get_fixes array sorted in either chronologically asc or desc order as a
        GeoPandas series. This creates a copy of the underlying get_fixes array so will suck memory. Because
        the fixtimes are used as the index, they have to be unique or this would fail. """
        gs = gpd.GeoSeries([shp.Point((p.ogr_geometry.GetX(), p.ogr_geometry.GetY()))
                            for p in self.get_fixes(temporal_order=temporal_order)],
                           index=[p.fixtime for p in self.get_fixes(temporal_order=temporal_order)])
        gs.crs = {'init': 'epsg:4326'}
        return gs

    def as_pandas_series(self, temporal_order='ASC'):
        """return a Geopandas Series containing the x,y coordinate of each point"""
        xy_s = pd.Series([(p.ogr_geometry.GetX(), p.ogr_geometry.GetY()) for p in self.get_fixes(temporal_order)],
                         index=[p.fixtime for p in self.get_fixes(temporal_order)])
        return xy_s

    def as_numpy_array(self, temporal_order='ASC'):
        """return a numpy array containing the x,y coordinate of each point"""
        xy_s = np.array([[p.ogr_geometry.GetX(), p.ogr_geometry.GetY()] for p in self.get_fixes(temporal_order)])
        #Could also combine x, and y vectors using: np.vstack([x,y]).T
        return xy_s

    def add_fix(self, fix):
        """ Add a fix to the get_fixes array"""
        if fix is not None:
            self._fixes.append(fix)

    def apply_fix_filter(self, fix_filter=None):
        """Apply a given filter by marking the fix junk_status based on the conditions of a filter"""

        # Identify junk fixes based on location coordinate x,y ranges or that match specific coordinates
        if isinstance(fix_filter, RelocsCoordinateFilter):
            for f in self._fixes:
                pnt = f.ogr_geometry
                if pnt.GetX() < fix_filter.min_x:
                    f.junk_status = True
                if pnt.GetX() > fix_filter.max_x:
                    f.junk_status = True
                if pnt.GetY() < fix_filter.min_y:
                    f.junk_status = True
                if pnt.GetY() > fix_filter.max_y:
                    f.junk_status = True
                tmp_coords = [pnt.GetX(), pnt.GetY()]
                if tmp_coords in fix_filter.filter_point_coords:
                    f.junk_status = True

        # Mark fixes outside this date range as junk
        if isinstance(fix_filter, RelocsDateRangeFilter):
            if fix_filter.start is not None:
                for f in self._fixes:
                    if f.fixtime < fix_filter.start:
                        f.junk_status = True
            if fix_filter.end is not None:
                for f in self._fixes:
                    if f.fixtime > fix_filter.end:
                        f.junk_status = True

        # Mark fixes junk if object needed to move faster than the max_speed_kmhr value to reach next point
        if isinstance(fix_filter, RelocsSpeedFilter):
            # Sort in asc order
            self.sort_fixes(temporal_order='ASC')
            for i in range(1, len(self._fixes)):
                if (self._fixes[i - 1].junk_status is False) and (self._fixes[i].junk_status is False):
                    tmp_seg = StraightTrackSeg(self._fixes[i - 1], self._fixes[i])
                    if tmp_seg.speed_kmhr > fix_filter.max_speed_kmhr:
                        self._fixes[i].junk_status = True

        # Mark fixes junk if object needed to move greater than the max_dist_meters value to reach next point
        if isinstance(fix_filter, RelocsDistFilter):
            # Sort in asc order
            self.sort_fixes(temporal_order='ASC')
            for i in range(1, len(self._fixes)):
                if (self._fixes[i - 1].junk_status is False) and (self._fixes[i].junk_status is False):
                    tmp_seg = StraightTrackSeg(self._fixes[i - 1], self._fixes[i])
                    if tmp_seg.length_km > fix_filter.max_dist_km:
                        self._fixes[i].junk_status = True

    def reset_fix_filter(self):
        for f in self._fixes:
            f.junk_status = False


class StraightTrackSeg(object):
    """Class representing the straight line geometry between start and end point"""

    def __init__(self, start_fix, end_fix):
        self._start_fix = start_fix
        self._end_fix = end_fix
        if (self._start_fix.geopoint is None) or (self._end_fix.geopoint is None):
            self._line = None

        # Build the line geometry
        self._line = ogr.Geometry(type=ogr.wkbLineString)
        self._line.AddPoint(self._start_fix.ogr_geometry.GetX(),
                            self._start_fix.ogr_geometry.GetY(),
                            self._start_fix.ogr_geometry.GetZ())
        self._line.AddPoint(self._end_fix.ogr_geometry.GetX(),
                            self._end_fix.ogr_geometry.GetY(),
                            self._end_fix.ogr_geometry.GetZ())

        # Build the line Spatial Reference System
        self._line.AssignSpatialReference(SRS.WGS84())
        self._srs_epsg_code = 4326

    @property
    def ogr_geometry(self):
        return self._line

    @property
    def start_fix_ogr_geometry(self):
        return self._start_fix.ogr_geometry

    @property
    def end_fix_ogr_geometry(self):
        return self._end_fix.ogr_geometry

    @property
    def start_fix_geopoint(self):
        return self._start_fix.geopoint

    @property
    def end_fix_geopoint(self):
        return self._end_fix.geopoint

    @property
    def start_fix(self):
        return self._start_fix

    @property
    def end_fix(self):
        return self._end_fix

    @property
    def midpoint_time(self):
        return self.start_fix + dt.timedelta(milliseconds=int(self.timespan_seconds*1000/2.0))

    @property
    def timespan_seconds(self):
        """Returns the total time between start and end times in seconds"""
        if (self._end_fix.fixtime is not None) and (self._start_fix.fixtime is not None):
            ts = self._end_fix.fixtime - self._start_fix.fixtime
            return ts.total_seconds()
        else:
            return 0

    @property
    def speed_kmhr(self):
        """Returns the straight-line (average) speed traveled between start and end get_fixes"""
        ts = self.timespan_seconds
        if ts != 0:
            return self.length_km / (ts / 3600)  # Km/Hr

    @property
    def heading(self):
        """ Returns the  the compass heading of the segment WRT True North """
        geod = Geodesic.WGS84
        great_circle = geod.Inverse(lat1=self._start_fix.ogr_geometry.GetY(),
                                    lon1=self._start_fix.ogr_geometry.GetX(),
                                    lat2=self._end_fix.ogr_geometry.GetY(),
                                    lon2=self._end_fix.ogr_geometry.GetX())
        azimuth = great_circle['azi1']
        if azimuth < 0:
            azimuth += 360
        return azimuth

    @property
    def length(self):
        """Returns the distance between point 1 & 2 in meters"""

        geod = Geodesic.WGS84
        great_circle = geod.Inverse(lat1=self._start_fix.ogr_geometry.GetY(),
                                    lon1=self._start_fix.ogr_geometry.GetX(),
                                    lat2=self._end_fix.ogr_geometry.GetY(),
                                    lon2=self._end_fix.ogr_geometry.GetX())
        return great_circle['s12']

    @property
    def length_km(self):
        return self.length / 1000.0


class TrajSegFilter:
    """Class filtering a set of trajectory segment segments"""

    def __init__(self, min_length_meters=0.0, max_length_meters=float("inf"), min_time_secs=0.0,
                 max_time_secs=float("inf"), min_speed_kmhr=0.0, max_speed_kmhr=float("inf")):
        self._min_length_meters = min_length_meters  # the minimum length in meters that a trackseg can be
        self._max_length_meters = max_length_meters  # the maximum length in meters that a trackseg can be (Nullable)
        self._min_time_secs = min_time_secs  # the minimum time in seconds that a trackseg can be
        self._max_time_secs = max_time_secs  # the maximum time in seconds that a trackseg can be
        self._min_speed_kmhr = min_speed_kmhr  # the minimum speed in KM/Hr that a trackseg can be
        self._max_speed_kmhr = max_speed_kmhr  # the maximum speed in Km/Hr that a trackseg can be

    @property
    def min_length_meters(self):
        return self._min_length_meters

    @property
    def max_length_meters(self):
        return self._max_length_meters

    @property
    def min_time_secs(self):
        return self._min_time_secs

    @property
    def max_time_secs(self):
        return self._max_time_secs

    @property
    def min_speed_kmhr(self):
        return self._min_speed_kmhr

    @property
    def max_speed_kmhr(self):
        return self._max_speed_kmhr


class Trajectory:

    """A trajectory represents a time-ordered collection of segments. Currently only 'StraightTrackSegments' exist.
     It is based on an underlying relocs object that is the point representation"""

    def __init__(self, relocs=None):
        self._relocs = relocs or Relocations()
        self._traj_seg_filter = None

    @property
    def relocs(self):
        """Return the relocs that make up the trajectory"""
        return self._relocs

    @property
    def traj_seg_filter(self):
        return self._traj_seg_filter

    @traj_seg_filter.setter
    def traj_seg_filter(self, value):
        assert type(value) is TrajSegFilter
        self._traj_seg_filter = value

    @property
    def traj_segs(self):
        """ Generate the trajectory segments subject to the  segment filter """

        """
        TODOs: 
            1) Not sure whether to use yield statements in here? 
            Leads to an error when trying to get a count of segments 
            
            2) Add directional persistence value to each trajseg (Avgar et al. 2012)
        """

        traj_segments = []
        tmpList = self._relocs.get_fixes()
        for i in range(1, len(tmpList)):
            trajSeg = StraightTrackSeg(tmpList[i - 1], tmpList[i])
            if self.traj_seg_filter is not None:
                if ((trajSeg.length_km * 1000.0) > self.traj_seg_filter.min_length_meters) and \
                        ((trajSeg.length_km * 1000.0) < self.traj_seg_filter.max_length_meters) and \
                        (trajSeg.timespan_seconds > self.traj_seg_filter.min_time_secs) and \
                        (trajSeg.timespan_seconds < self.traj_seg_filter.max_time_secs) and \
                        (trajSeg.speed_kmhr > self.traj_seg_filter.min_speed_kmhr) and \
                        (trajSeg.speed_kmhr < self.traj_seg_filter.max_speed_kmhr):
                    traj_segments.append(trajSeg)
            else:
                traj_segments.append(trajSeg)
        return traj_segments

    @property
    def traj_seg_count(self):
        """A shortcut to getting the length of the trajectory segments array"""
        return len(self.traj_segs)

    @property
    def tortuosity(self):
        #TODO Need to implement this property
        return 1.0

    @property
    def length_km(self):
        total_dist = 0
        for seg in self.traj_segs:
            total_dist = total_dist + seg.length_km
        return total_dist

    @property
    def ogr_geometry(self):
        # Create an OGR multistring object

        polyline = ogr.Geometry(ogr.wkbMultiLineString)
        polyline.AssignSpatialReference(SRS.WGS84())

        for seg in self.traj_segs:
            seg_geo = seg.ogr_geometry
            if seg_geo is not None:
                polyline.AddGeometry(seg_geo)
        return polyline

    def resample(self):
        #TODO: Need to implement this method
        pass

    def speed_percentiles(self, percentiles=None, ignore_zeroes=True):
        speeds = []
        for s in self.traj_segs:
            if ignore_zeroes is True:
                if s.speed_kmhr > 0.0:
                    speeds.append(s.speed_kmhr)
            else:
                speeds.append(s.speed_kmhr)
        speeds = pd.Series(speeds)
        if percentiles is None:
            percentiles = [0.5]
        if not isinstance(percentiles, list):
            percentiles = [percentiles]
        return speeds.quantile(q=percentiles, interpolation='linear').to_dict()


class AnalysisParams:
    """ An abstract class that acts as a container for calculation parameters"""
    pass


class AnalysisResult:
    """An abstract class to act as a container for calculation results"""

    def __init__(self):
        self._analysis_start = dt.datetime.utcnow()
        self._analysis_end = dt.datetime.utcnow()
        self._errors = []

    @property
    def analysis_start(self):
        return self._analysis_start

    @analysis_start.setter
    def analysis_start(self, value):
        if isinstance(value, dt.datetime):
            self._analysis_start = value

    @property
    def analysis_end(self):
        return self._analysis_end

    @analysis_end.setter
    def analysis_end(self, value):
        if isinstance(value, dt.datetime):
            self._analysis_end = value

    @property
    def errors(self):
        return self._errors

    def add_error(self, value):
        self._errors.append(value)


class SpatialFeature:
    """
    A spatial geometry with an associated name and unique ID. Becomes a useful construct in several pymet calculations
    """

    def __init__(self, ogr_geometry=None, name='', unique_id=None):
        self._ogr_geometry = ogr_geometry
        self._name = name
        self._unique_id = unique_id or uuid.uuid4()

    @property
    def name(self):
        return str(self._name)

    @property
    def unique_id(self):
        return self._unique_id

    @property
    def ogr_geometry(self):
        return self._ogr_geometry


class Region:
    """
    A polygon with an associated name. Becomes a useful construct in several pymet calculations
    """

    def __init__(self, ogr_geometry=None, region_name='', unique_id=''):
        self._ogr_geometry = ogr_geometry
        self._region_name = region_name
        self._unique_id = unique_id

    @property
    def region_name(self):
        return str(self._region_name)

    @property
    def unique_id(self):
        return self._unique_id

    @property
    def ogr_geometry(self):
        return self._ogr_geometry


class RasterOutputParams:
    """ A class for holding raster output parameters"""

    def __init__(self, pixel_size=500.0,
                 out_name='pymet_rast.img', srs_epsg=4326, no_data_value=0.0, expansion_factor=1.0):
        self._pixel_size = pixel_size
        self._out_name = out_name
        self._srs_epsg = srs_epsg
        self._no_data_value = no_data_value
        self._expansion_factor = expansion_factor

    @property
    def pixel_size(self):
        return self._pixel_size

    @property
    def out_name(self):
        return self._out_name

    @property
    def srs_epsg_code(self):
        return self._srs_epsg

    @property
    def no_data_value(self):
        return self._no_data_value

    @property
    def expansion_factor(self):
        return self._expansion_factor


class RasterEngine:
    """
    A class with functions for working with raster data
    """

    # Meter to Decimal Degree Conversion
    # Based on an average earth radius of 6367516.477 from WGS84 Datum
    ONE_METER_IN_DD = (180.0 / (6367516.477 * np.pi))

    @classmethod
    def random_image_array(cls, cols, rows):
        return np.array([np.random.random_integers(0, 255, cols) for x in range(0, rows - 1)])

    @classmethod
    def blank_raster_from_geo(cls, ingeo, pixel_size, no_data_value, out_rast):

        #Determine the extent of the input geometry
        env = ingeo.GetEnvelope()
        x_min, x_max, y_min, y_max = env[0], env[1], env[2], env[3]
        #print(pixel_size)
        #print(x_min, x_max, y_min, y_max)
        
        # Determine the output raster size
        num_columns = int((x_max - x_min) / pixel_size) #Calculate number of image columns
        num_rows = int((y_max - y_min) / pixel_size) # Calculate number of image rows
        #print(num_columns, num_rows)

        #Create the raster file
        driver = gdal.GetDriverByName('GTiff')
        target_ds = driver.Create(out_rast, num_columns, num_rows, gdal.GDT_Byte)

        #Define the affine transform for converting between image coordinates and map coordinates
        target_ds.SetGeoTransform((x_min, pixel_size, 0, y_max, 0, -pixel_size))
        
        #Set the band values
        band = target_ds.GetRasterBand(1)
        band.SetNoDataValue(no_data_value)
        
        #Set the output spatial reference
        target_ds.SetProjection(SRS.WGS84().ExportToWkt())

        array = RasterEngine.random_image_array(num_columns, num_rows)
        print(array)
        reversed_arr = array[::-1]
        band.WriteArray(reversed_arr)
        band.FlushCache()

    @classmethod
    def rasterize_vector_data(cls, vector_fn, pixel_size, NoData_value, raster_fn):
        # Open the data source and read in the extent

        source_ds = ogr.Open(vector_fn)
        source_layer = source_ds.GetLayer()
        x_min, x_max, y_min, y_max = source_layer.GetExtent()
        print(x_min, x_max, y_min, y_max)

        # Create the destination data source
        x_res = int((x_max - x_min) / pixel_size)
        y_res = int((y_max - y_min) / pixel_size)
        target_ds = gdal.GetDriverByName('GTiff').Create(raster_fn, x_res, y_res, 1, gdal.GDT_Byte)
        target_ds.SetGeoTransform((x_min, pixel_size, 0, y_max, 0, -pixel_size))
        band = target_ds.GetRasterBand(1)
        band.SetNoDataValue(NoData_value)

        # Rasterize
        gdal.RasterizeLayer(target_ds, [1], source_layer, burn_values=[1])


class PymetException(Exception):
    """ A custom exception type for pymet specific errors"""
    pass