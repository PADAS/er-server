import datetime as dt
import time
import sys
import shapely
import geojson
import numpy as np
import ee
import geopandas as gpd

import logging
logger = logging.getLogger(__name__)

import os
# service_account_email = 'service@classifier-ele.iam.gserviceaccount.com'
# KEY_FILE = '/Users/chris/padas/annotations/tools/classifier-655bc9a08ac7.json'

service_account_email = os.getenv('EARTHENGINE_SERVICE_ACCOUNT', None)
key_file = os.getenv('EARTHENGINE_KEY_FILE', None)

try:
    if service_account_email and key_file:
        logger.info('Earth Engine client will be initialized with service account: %s', service_account_email)
        credentials = ee.ServiceAccountCredentials(service_account_email, key_file=key_file)
        ee.Initialize(credentials)

        logger.info('Earth Engine client is initialized.')
    else:
        logger.info('Earth Engine client will not be initialized.')

except ee.ee_exception.EEException as e:
    logger.warning('Earth Engine client is not initialized.')


# useful stylizations
colourPalettes = {'precipitation': {'palette': ['00FFFF', '0000FF']}, }


def convert_millisecs_datetime(unix_time):
    # Define the UNIX Epoch start date
    epoch = dt.datetime(1970, 1, 1, 0, 0, 0)
    t = epoch + dt.timedelta(milliseconds=unix_time)
    return t


def convert_datetime_millisecs(input_time):
    # Define the UNIX Epoch start date
    epoch = dt.datetime(1970, 1, 1, 0, 0, 0)
    return int((input_time - epoch).total_seconds() * 1000)


def convertUnixTimeToDateTime(unixTime):
    t=dt.datetime.utcfromtimestamp(int(unixTime/1000))
    #return t.strftime('%Y-%m-%d %H:%M:%S')
    return t


def add_img_time(img):

    """ A function to add the date range of the image as one of its
    properties and the start and end values as new bands"""

    # unable to use the band rename() function here in Python whereas works in JS playground
    img = img.addBands(img.metadata('system:time_start'))
    # timestamp = img.select(0).multiply(0).long()
    # timestamp = timestamp.add(img.metadata('system:time_start'))
    # img = img.addBands(timestamp)

    img = img.addBands(img.metadata('system:time_end'))
    # timestamp = img.select(0).multiply(0).long()
    # timestamp = timestamp.add(img.metadata('system:time_end'))
    # img = img.addBands(timestamp)

    dr = ee.DateRange(ee.Date(img.get('system:time_start')),
                      ee.Date(img.get('system:time_end')))

    return img.set({'date_range': dr})


def fixes_to_featurecollection(fixes):

    """ A function to turn a relocations object into a GEE feature collection"""

    return ee.FeatureCollection([ee.Feature(ee.Geometry.Point(p.geopoint.longitude, p.geopoint.latitude),
                                            {'fixtime': p.fixtime.replace(tzinfo=None), 'id': p.uuid})
                                 for p in fixes])


def gdf_to_featurecollection(gdf):
    feats=[]
    for i, row in gdf.iterrows():
        ee_feat = ee.Feature(geojson_to_ee_geometry(shapely.geometry.mapping(row.geometry)))
        feats.append(ee_feat)
    return ee.FeatureCollection(feats)


def geojson_to_ee_geometry(s):
    """
    A function to convert geojson to an ee.Geometry
    :param s: can either be a geojson formatted string or dict
    :return: ee.Geometry or None
    """
    result = None
    if type(s) is str:
        result = ee.Geometry(geojson.loads(s)) #ToDo: test this with actual geojson strings
    elif type(s) is dict:
        result = ee.Geometry(s)

    return result


def geofile_to_gdf(geofile=''):
    """ Read a geofile into a geopandas dataframe. Supports formats used by fiona"""
    return gpd.GeoDataFrame.from_file(geofile)


# In use by DAS_analyzers
def extract_point_values_from_image(relocs, img_name='', band_name='b1', scale=500.0):
    """A function to extract values from an image at relocation points"""

    # Exit if the relocs object is null
    if relocs is None:
        return

    # Build the relocations object into a GEE feature collection
    feat_coll = fixes_to_featurecollection(relocs.get_fixes())

    try:
        img = ee.Image(img_name)

        # dictionary result of the reduction
        result = img.reduceRegion(ee.Reducer.toList(), feat_coll.geometry(), scale).getInfo()
        #print(result)

        if result is not None:
            raw_vals = result.get(band_name)
            if raw_vals is not None:
                return np.mean(raw_vals)
    except:
        return


def extract_point_vals_from_temporal_img_coll(fixes, img_coll, calc_name='gee_calc',
                                              before_win=16*24*60*60, after_win=0, nearest=1,
                                              temporal_intersect=False, scale=500.0, chunk_size=20):

    """
    A function to filter the image collection to just those images that either intersect the fixtime daterange,
    or are the closest temporally, and intersect the geometry of the feature and then extract the image pixel
    values.

    fixes: a list of fix objects
    img_coll: the GEE image collection
    calc_name: the name to give this particular calculation. It will be the key to use to look up results in the
    fix's gee_result dictionary
    before_win: the amount of time in seconds to select before the fix's fixtime. Set to 0 for the fixtime only
    after_win: the amount of time in seconds to select after the fix's fixtime set to 0 for the fixtime
    nearest: the number of images to select that are temporally close to the fixtime. Use zero for all images
    temporal_intersect: require that the image's daterange intersects with the fixe's daterange
    scale: the pixel size in meters at which to resample the imagery
    chunk_size: the number of features that should be processed at once within GEE. This helps limiting memory errors
    """

    # Exit if the fixes list are null or empty
    if (fixes is None) or (fixes == []):
        return

    # Add date ranges to all the images in the collection
    img_coll = img_coll.map(add_img_time)

    # Define the function to map over each feature
    def map_features(feat):

        fixtime = ee.Date(feat.get('fixtime'))
        t1 = fixtime.advance(-1 * before_win, 'second')
        t2 = fixtime.advance(after_win, 'second')
        feat_dr = ee.DateRange(t1, t2)

        # filter the image collection by geometry
        tmpColl = img_coll.filterBounds(feat.geometry())

        # calculate how far away in time the image time_start value is from the current fix's fixtime
        # and whether the image timespan intersects the fix's designated time window
        def temporal_proximity(img):
            temporal_dist = img.date().difference(ee.Date(feat.get('fixtime')), 'second')
            img = img.set({'temporal_dist': temporal_dist})
            img = img.set({'temporal_intersects': feat_dr.intersects(img.get('date_range'))})
            return img

        tmpColl = tmpColl.map(temporal_proximity)

        # Only include images whose date range intersects the date range of the feature
        tmpColl = ee.ImageCollection(ee.Algorithms.If(temporal_intersect,
                                                      tmpColl.filter(ee.Filter.eq('temporal_intersects', True)),
                                                      tmpColl))

        tmpColl = ee.ImageCollection(ee.Algorithms.If(nearest,
                                                      tmpColl.sort('temporal_dist', True).limit(nearest), tmpColl))

        # Reduce
        tmpColl = tmpColl.toArray()
        tmp_reduce = tmpColl.reduceRegion(ee.Reducer.toList(), feat.geometry(), scale)

        return feat.set({'img_vals': tmp_reduce})

    for i in range(0, len(fixes), chunk_size): #len(fixes)
        print('Analyzing features: ', str(i), ' to ', str(i + chunk_size))
        chunk = fixes[i:i + chunk_size]

        # Build the relocations object into a GEE feature collection
        feat_coll = fixes_to_featurecollection(chunk)

        success = False
        while success is False:
            # The while loop lets us try over if the GEE servers didn't respond and we get a server timeout error.
            # Because of lazy execution the servers may not be finished running a calc but the next time you
            # try the result is ready.
            # ToDo: figure out how to discern between a result not ready error and some other error type

            try:
                # Run the map function over all features
                result = feat_coll.map(map_features).getInfo()
                success = True

                # Create a dictionary using the fix ID values as the key:
                tmp_results = dict()
                for feat in result.get('features'):
                    tmp_results[feat.get('properties').get('id')] = \
                        feat.get('properties').get('img_vals').get('array')[0]

                # Set the results for each input fix
                for fix in chunk:
                    # look up the result value for the given id
                    if not hasattr(fix, 'gee_result'):
                        fix.gee_result = dict()
                    fix.gee_result[calc_name] = tmp_results.get(fix.uuid)

            except:
                print(str(sys.exc_info()[0]))
                print('Re-trying in 5 seconds...')
                time.sleep(5)  # Pause for 5 seconds before trying again

        # Here was a test to see if I could use a callback like in the js playground
        # but does't seem implemented for python
        # def jrslt(itworked,itfailed):
        #     if itworked:
        #         # Create a dictionary using the fix ID values as the key:
        #         tmp_results = dict()
        #         for feat in result.get('features'):
        #             tmp_results[feat.get('id')] = feat.get('properties').get('img_vals').get('array')[0]
        #
        #         # Set the results for each input fix
        #         for fix in chunk:
        #             # look up the result value for the given id
        #             fix.gee_result = tmp_results.get(fix.uuid)
        #     else:
        #         print('something went wrong')
        #         print(str(itfailed))
        #
        #
        # print('Running map...')
        # result = feat_coll.map(map_features).evaluate(jrslt)
        # success = True
        # print('successful')


def ReduceRegionByDatetimes(image_stack,
                            region,
                            region_scale,
                            ee_region_reducer_type,
                            ee_stack_reducer_type,
                            band_name,
                            datetimes=[]):

    """A function to perform a series of image stack reductions on the chosen band
     within the given region and for the given datetime tuples"""

    # Get the GPM dataset
    imgColl = ee.ImageCollection(image_stack).select(band_name).sort('system:time_start', False)

    # Convert the datetime tuples into a feature collection
    featColl = ee.FeatureCollection([ee.Feature(None, {'startDate': x[0], 'endDate': x[1]}) for x in datetimes])

    def mapFunc(feat):
        reduc = imgColl.filterDate(feat.get('startDate'), feat.get('endDate')).reduce(
            ee_stack_reducer_type).reduceRegion(ee_region_reducer_type, region.geometry(), region_scale)
        return feat.set({'reduceVal': reduc})

    return [(convert_millisecs_datetime(x.get('properties').get('startDate').get('value')),
             x.get('properties').get('reduceVal').get(band_name + '_' + ee_stack_reducer_type))
            for x in featColl.map(mapFunc).getInfo()['features']]

def extract_img_coll_pixel_values(img_coll, region_geometry, calc_name='GEE_Img_Coll_Pix_Vals', scale=500.0):
    """
    A function to extract and return the pixel values
    :param img_coll:
    :param calc_name:
    :param scale:
    :return:
    """

    # Reduce
    tmpColl = img_coll.map(add_img_time).toArray()
    result = tmpColl.reduceRegion(ee.Reducer.toList(), region_geometry, scale).getInfo()
    return result
