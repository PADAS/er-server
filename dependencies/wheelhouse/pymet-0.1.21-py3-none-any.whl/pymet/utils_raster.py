import numpy as np
from osgeo import gdal, gdalconst
import pymet.base as base
from osgeo import ogr
import math
import os
import tempfile
from joblib import load, dump
import shutil
import gc


class ExtendCoords:
    def __init__(self, x_min, x_max, y_min, y_max):
        self.x_min = x_min
        self.x_max = x_max
        self.y_min = y_min
        self.y_max = y_max


class RasterProps:
    """ A class for holding raster properties
    At present this class is only valid for non-rotated rasters with a north-up orientation
    """

    def __init__(self,
                 name='pymet_rast.img',
                 storage_location='',
                 pixel_size=500.0,
                 gdal_pixel_type=gdal.GDT_Float64,
                 gdal_rast_type='HFA',
                 srs_epsg=4326,
                 no_data_value=0.0,
                 band_count=1,
                 extent_coords=None):
        self._name = name
        self._storage_location = storage_location
        self._pixel_size = pixel_size
        self._pixel_type = gdal_pixel_type
        self._gdal_rast_type = gdal_rast_type
        self._srs_epsg = srs_epsg
        self._no_data_value = no_data_value
        self._band_count = band_count
        self._extent_coords = extent_coords

    @property
    def name(self):
        return self._name

    @property
    def storage_location(self):
        return self._storage_location

    @property
    def pixel_size(self):
        return self._pixel_size

    @property
    def gdal_pixel_type(self):
        return self._pixel_type

    @property
    def gdal_rast_type(self):
        return self._gdal_rast_type

    @property
    def srs_epsg_code(self):
        return self._srs_epsg

    @property
    def no_data_value(self):
        return self._no_data_value

    @property
    def band_count(self):
        return self._band_count

    @property
    def extent_coords(self):
        return self._extent_coords  # x_min, x_max, y_min, y_max

    @extent_coords.setter
    def extent_coords(self, value):
        assert(value is ExtendCoords)
        self._extent_coords = value

    @property
    def num_columns(self):
        return int(math.ceil((self.extent_coords.x_max - self.extent_coords.x_min) / self.pixel_size))

    @property
    def num_rows(self):
        return int(math.ceil((self.extent_coords.y_max - self.extent_coords.y_min) / self.pixel_size))

    @property
    def pixel_to_map_trans(self):
        return self.extent_coords.x_min, self.pixel_size, 0, self.extent_coords.y_max, 0, -self.pixel_size


class Raster:

    def __init__(self, rast_props=None, gdal_rast=None):
        self._rast_props = rast_props
        self._gdal_rast = gdal_rast
        self._outband = None
        self._gdal_array = None
        self._ndarray_tmp = None
        self._tmpfolders=[]

    def __del__(self):

        self._gdal_array = None
        self._ndarray_tmp = None
        self._outband = None
        gc.collect()

        if self._tmpfolders is not None:
            for f in self._tmpfolders:
                try:
                    shutil.rmtree(f)  # this does not seem to be working
                except:
                    print("Failed to delete: " + f)


    @property
    def rast_props(self):
        return self._rast_props

    @property
    def gdal_raster(self):
        return self._gdal_rast

    def pixel_data(self, band=1):
        try:

            # Get a hold of the raster output band
            self._outband = self.gdal_raster.GetRasterBand(band)

            # self._gdal_array = np.zeros(shape=(self.rast_props.num_rows,
            #  self.rast_props.num_columns), dtype=np.float64)

            # Create a temporary folder
            folder = tempfile.mkdtemp()
            self._tmpfolders.append(folder)

            print(folder)

            self._ndarray_tmp = os.path.join(folder, 'pymet_ndarray.mmap')

            # Read the image values into the joblib mmap
            if os.path.exists(self._ndarray_tmp):
                os.unlink(self._ndarray_tmp)

            # ToDo: is there a way to give joblib a mmap object from gdal
            # rather than reading whole image into memory?
            dump(self._outband.ReadAsArray(), self._ndarray_tmp)

            self._gdal_array = load(self._ndarray_tmp, mmap_mode='w+')

            return self._outband, self._gdal_array

        except Exception as ex:
            print(ex)



class RasterEngine:
    """
    A class with functions for working with raster data
    """

    # Meter to Decimal Degree Conversion
    # Based on an average earth radius of 6367516.477 from WGS84 Datum
    ONE_METER_IN_DD = (180.0 / (6367516.477 * np.pi))

    @classmethod
    def create_raster(cls, rast_props=None, expansion_factor=1.0):

        # Supported gdal raster types: GTiff, HFA,
        # Supported gdal pixel types: GDT_Byte, GDT_Float64
        output_raster = None
        try:

            # Determine the extent of the input geometry
            x_min, x_max, y_min, y_max = rast_props.extent_coords.x_min, rast_props.extent_coords.x_max, \
                                         rast_props.extent_coords.y_min, rast_props.extent_coords.y_max

            # Determine the envelope wrt to the expansion_factor
            if expansion_factor > 1.0:
                dx = (x_max - x_min) * (expansion_factor - 1.0) / 2.0
                dy = (y_max - y_min) * (expansion_factor - 1.0) / 2.0
                x_min -= dx
                x_max += dx
                y_min -= dy
                y_max += dy
                rast_props.extent_coords.x_min = x_min
                rast_props.extent_coords.x_max = x_max
                rast_props.extent_coords.y_min = y_min
                rast_props.extent_coords.y_max = y_max

            # Create the raster file
            driver = gdal.GetDriverByName(rast_props.gdal_rast_type)
            outlocation = os.path.join(rast_props.storage_location, rast_props.name)
            gdal_raster = driver.Create(utf8_path=outlocation,
                                          xsize=rast_props.num_columns,
                                          ysize=rast_props.num_rows,
                                          bands=rast_props.band_count,
                                          eType=rast_props.gdal_pixel_type)

            # Define the affine transform for converting between image coordinates and map
            gdal_raster.SetGeoTransform(rast_props.pixel_to_map_trans)

            # Set the band no data values
            for i in range(rast_props.band_count):
                band = gdal_raster.GetRasterBand(i + 1)
                band.SetNoDataValue(rast_props.no_data_value)

            # Set the output spatial reference
            gdal_raster.SetProjection(base.SRS.srs_from_epsg(rast_props.srs_epsg_code).ExportToWkt())

            output_raster = Raster(rast_props, gdal_rast=gdal_raster)

        except Exception as ex:
            print(ex)

        finally:
            return output_raster


    @classmethod
    def random_image_array(cls, cols, rows):
        return np.array([np.random.random_integers(0, 255, cols) for x in range(0, rows - 1)])

    @classmethod
    def rasterize_vector_data(cls, vector_fn, pixel_size, NoData_value, raster_fn):
        # Open the data source and read in the extent

        source_ds = ogr.Open(vector_fn)
        source_layer = source_ds.GetLayer()
        x_min, x_max, y_min, y_max = source_layer.GetExtent()
        print(x_min, x_max, y_min, y_max)

        # Create the destination data source
        x_res = int((x_max - x_min) / pixel_size)
        y_res = int((y_max - y_min) / pixel_size)
        target_ds = gdal.GetDriverByName('GTiff').Create(raster_fn, x_res, y_res, 1, gdal.GDT_Byte)
        target_ds.SetGeoTransform((x_min, pixel_size, 0, y_max, 0, -pixel_size))
        band = target_ds.GetRasterBand(1)
        band.SetNoDataValue(NoData_value)

        # Rasterize
        gdal.RasterizeLayer(target_ds, [1], source_layer, burn_values=[1])


