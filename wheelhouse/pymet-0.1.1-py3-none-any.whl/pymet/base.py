import datetime
from geographiclib.geodesic import Geodesic
from osgeo import ogr
from osgeo import osr


class WGS84:
    @classmethod
    def get_WGS84(self):
        srs = osr.SpatialReference()
        srs.ImportFromEPSG(4326)
        return srs


class GeoPoint:
    """A geographic point is the most basic geometry"""

    def __init__(self, x=0, y=0, z=0):
        """Create a new point with the supplied geographic coordinates.
        Defaults to WGS84 SRS """

        self.point = ogr.Geometry(type=ogr.wkbPoint)
        self.srs_EPSG_Code = 4326
        srs = WGS84.get_WGS84()
        self.point.AddPoint(x, y, z)
        self.point.AssignSpatialReference(srs)

    def get_point(self):
        """ Return the ogr point """
        return self.point

    def get_SRS_EPSG_Code(self):
        """Return the spatial reference system EPSG code"""
        return self.srs_EPSG_Code

    def __str__(self):
        return str(self.get_point())


class Fix:
    """A Fix is a temporal geopoint"""

    def __init__(self, geopoint, fixtime):
        self.Fixtime = fixtime
        self.GeoPoint = geopoint

    def get_fixtime(self):
        """ Return the fixtime"""
        return self.Fixtime

    def get_geopoint(self):
        """Return the geopoint"""
        return self.GeoPoint


class Relocations:
    """Relocations are a set of fixes"""

    def __init__(self, fixes=[]):
        if fixes is None:
            fixes = []
        self.fixes = fixes

    # TODO:
    def timespan(self):
        pass

    # TODO:
    def displacement(self):
        pass

    def relocs_fix_count(self):
        """Shortcut to the relocations fixes array length"""
        if self.fixes is not None:
            return len(self.fixes)
        else:
            return 0

    def get_fixes(self, temporal_order='ASC'):
        """Instance method to access the fixes array sorted in either chronologically asc or dsc order"""

        if temporal_order == 'DSC':
            return self.fixes  # Need to sort this array of fixes in descending order...
        else:
            return self.fixes


class StraightTrackSeg(object):
    """Class representing the straight line geometry between start and end point"""

    def __init__(self, start_fix, end_fix):
        self.start_fix = start_fix
        self.end_fix = end_fix
        if (self.start_fix.get_geopoint() is None) or (self.end_fix.get_geopoint() is None):
            self.line = None

        # Build the line geometry
        self.line = ogr.Geometry(type=ogr.wkbLineString)
        self.line.AddPoint(self.start_fix.get_geopoint().get_point().GetX(),
                           self.start_fix.get_geopoint().get_point().GetY(),
                           self.start_fix.get_geopoint().get_point().GetZ())
        self.line.AddPoint(self.end_fix.get_geopoint().get_point().GetX(),
                           self.end_fix.get_geopoint().get_point().GetY(),
                           self.end_fix.get_geopoint().get_point().GetZ())

        # Build the line SRS
        self.line.AssignSpatialReference(WGS84.get_WGS84())
        self.srsEPSGCode = 4326

    def get_line(self):
        return self.line

    def get_start_fix(self):
        return self.start_fix

    def get_end_fix(self):
        return self.end_fix

    def mid_point_time(self):
        pass  # To-do: return the mid-way time between start and end

    def total_time(self):
        """returns the total time between start and end times in seconds"""
        if (not self.end_fix.get_fixtime() is None) and (not self.start_fix.get_fixtime() is None):
            ts = self.end_fix.get_fixtime() - self.start_fix.get_fixtime()
            return ts.total_seconds()
        else:
            return 0

    def speed(self):
        if self.total_time() != 0:
            return (self.length() / 1000) / (self.total_time() / 3600)  # Km/Hr

    def heading(self):
        """ returns the  the compass heading of the segment WRT True North """
        geod = Geodesic.WGS84
        great_circle = geod.Inverse(self.start_fix.get_geopoint().get_point().GetX(),
                                    self.start_fix.get_geopoint().get_point().GetY(),
                                    self.end_fix.get_geopoint().get_point().GetX(),
                                    self.end_fix.get_geopoint().get_point().GetY())
        azimuth = great_circle['azi1']
        if azimuth < 0:
            azimuth += 360
        return azimuth

    def length(self):
        """Return the distance between point 1 & 2 in meters"""
        geod = Geodesic.WGS84
        great_circle = geod.Inverse(self.start_fix.get_geopoint().get_point().GetX(),
                                    self.start_fix.get_geopoint().get_point().GetY(),
                                    self.end_fix.get_geopoint().get_point().GetX(),
                                    self.end_fix.get_geopoint().get_point().GetY())
        return great_circle['s12']


class TrackSegFilter:
    """Class filtering a set of track segments"""

    def __init__(self, min_length, max_length, min_time, max_time, min_speed, max_speed):
        self.min_length = min_length  # the minimum length in meters that a trackseg can be
        self.max_length = max_length  # the maximum length in meters that a trackseg can be (Nullable)
        self.min_time = min_time  # the minimum time in seconds that a trackseg can be
        self.max_time = max_time  # the maximum time in seconds that a trackseg can be
        self.min_speed = min_speed  # the minimum speed in KM/Hr that a trackseg can be
        self.max_speed = max_speed  # the maximum speed in Km/Hr that a trackseg can be


class Trajectory:
    """A trajectory is a collection of relocations. Can have both point series and a
    track segment series representations"""

    def __init__(self, relocations):
        self.relocations = relocations

    # TODO apply the segment filter
    def relocs_fix_count(self):
        """Shortcut to the relocations fixes array length"""
        if self.relocations is not None:
            return len(self.relocations.get_fixes())
        else:
            return 0

    #TODO add functionality for filtering
    def get_track_segments(self, segfilter):
        """Turn the trajectory into a list of tracksegments subject to the filter"""
        trajSegments = []
        relocsLen = len(self.relocations.fixes)
        if relocsLen > 1:
            for i in range(1, relocsLen):
                trajSeg = StraightTrackSeg(self.relocations.get_fixes()[i - 1], self.relocations.get_fixes()[i])
                trajSegments.append(trajSeg)
            return trajSegments
        else:
            return None

    # TODO:
    def tortuosity(self):
        pass

    # TODO:
    def total_distance(self):
        pass

    # TODO:
    def resample(self):
        pass

    def get_geos_multilinestring_geometry(self, segfilter=None):
        # Create an OGR multistring object
        polyline = ogr.Geometry(ogr.wkbMultiLineString)
        polyline.AssignSpatialReference(WGS84.get_WGS84())

        for seg in self.get_track_segments(segfilter):
            segGeo = seg.getLine()
            if segGeo is not None:
                polyline.AddGeometry(segGeo)
        return polyline
