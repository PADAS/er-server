import ee
import datetime as dt


# stylizations
colourPalettes = {'precipitation': {'palette': ['00FFFF', '0000FF']}, }


def ReduceRegionByDatetimes(cls,
                            image_stack,
                            region,
                            region_scale,
                            ee_region_reducer_type,
                            ee_stack_reducer_type,
                            precip_band_name,
                            datetimes=[]):

    """A function to perform a series of image stack reductions on the chosen band
     within the given region and for the given timespans"""

    # Get the GPM dataset
    precipColl = ee.ImageCollection(image_stack).select(precip_band_name).sort('system:time_start', False)

    # Convert the date ranges into a feature collection
    featColl = ee.FeatureCollection([ee.Feature(None, {'startDate': x[0], 'endDate': x[1]}) for x in datetimes])

    def mapFunc(feat):
        reduc = precipColl.filterDate(feat.get('startDate'), feat.get('endDate')).reduce(
            ee_stack_reducer_type).reduceRegion(ee_region_reducer_type, region.geometry(), region_scale)
        return feat.set({'precipVal': reduc})

    return [(convertUnixTimeToDateTime(x.get('properties').get('startDate').get('value')),
             x.get('properties').get('precipVal').get(precip_band_name + '_' + ee_stack_reducer_type))
            for x in featColl.map(mapFunc).getInfo()['features']]


def convertUnixTimeToDateTime(unixTime):
    t = dt.datetime.utcfromtimestamp(int(unixTime / 1000))
    return t

def convertDateTimeToUnixTime(inputTime):
    # Define the UNIX Epoch start date
    epoch = dt.datetime(1970, 1, 1, 0, 0, 0)
    return int((inputTime - epoch).total_seconds() * 1000)
