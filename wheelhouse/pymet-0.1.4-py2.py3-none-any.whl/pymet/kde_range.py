from pymet import base
import datetime
import math
import numpy as np
from osgeo import gdal


class KDEAnalysisParams(base.AnalysisParams):

    def __init__(self,
                 smoothing_parameter=0.0,
                 smoothing_method='hRef',
                 max_sd=5.0,
                 prob_dens_cut_off=1E-15,
                 rast_output_params=None):

        self._smoothing_parameter = smoothing_parameter
        self._smoothing_method = smoothing_method
        self._max_sd = max_sd
        self._prob_dens_cut_off = prob_dens_cut_off
        self._rast_output_params = rast_output_params

    @property
    def smoothing_parameter(self):
        return self._smoothing_parameter

    @smoothing_parameter.setter
    def smoothing_parameter(self, value):
        self._smoothing_parameter = value

    @property
    def smoothing_method(self):
        return self._smoothing_method

    @property
    def max_sd(self):
        return self._max_sd

    @property
    def prob_dens_cut_off(self):
        return self._prob_dens_cut_off

    @property
    def rast_output_params(self):
        return self._rast_output_params


class KDEAnalysisResult(base.AnalysisResult):

    def __init__(self, out_rast=None):
        self._out_rast=out_rast

    @property
    def out_rast(self):
        return self._out_rast

    @out_rast.setter
    def out_rast(self, value):
        self._out_rast = value


class KDEAnalysis:

    @classmethod
    def CalculateKernelDensityRange(cls, kde_analysis_params, trajectory=None):

        # Create kde_analysis_result object
        kde_analysis_result = KDEAnalysisResult()
        kde_analysis_result.AnalysisStart = datetime.datetime.utcnow()

        try:
            # Test to make sure the calculation parameters are not None and the correct type
            assert type(kde_analysis_params) is KDEAnalysisParams

            # Make sure that the trajectory is not None
            if trajectory is None:
                raise base.PymetException('KDE Analysis Error: Trajectory was None.')

            # Retrieve the Geopandas series for the trajectory
            traj_series = trajectory.relocations.get_Geopandas_series()

            #Project to the desired output SRS
            if kde_analysis_params.rast_output_params.srs_epsg != 4326:
                traj_series = traj_series.to_crs(epsg=kde_analysis_params.rast_output_params.srs_epsg)

            # Retrieve the x,y coordinates of the relocations into a numpy array
            traj_coords = np.array([[i[1].x, i[1].y]for i in traj_series.iteritems()])

            # Try to calculate the smoothing parameter if nothing supplied
            if kde_analysis_params.smoothing_parameter == 0.0:
                if kde_analysis_params.smoothing_method == "hRef":
                    kde_analysis_params.smoothing_parameter = \
                        KDEAnalysis.Calc_hRef_SmoothingParameter(x=traj_coords[:, 0], y=traj_coords[:, 1])
                else:
                    raise base.PymetException('KDE Analysis Error: ' +
                                                    kde_analysis_params.smoothing_method + ' is not supported yet.')

            # Test that the smoothing parameter is not zero
            if kde_analysis_params.smoothing_parameter == 0.0:
                raise base.PymetException('KDE Analysis Error: smoothing parameter is zero.')

            # Define the scaling parameters
            outerScalingConstant = 1.0 / (trajectory.relocations.getFixCount() *
                                          kde_analysis_params.smoothing_parameter *
                                          kde_analysis_params.smoothing_parameter)

            innerScalingConstant = 1.0 / (2.0 * np.pi)

            # Determine the max distance value
            variance = 2.0 * kde_analysis_params.smoothing_parameter * kde_analysis_params.smoothing_parameter
            maxDist = math.pow(kde_analysis_params.max_sd, 2.0) * variance

            # Determine the envelope of the trajectory
            #env = trajectory.getRelocations().getOGRMultiPointGeometry().GetEnvelope()
            #x_min, x_max, y_min, y_max = env[0], env[1], env[2], env[3]
            x_min = traj_coords[:, 0].min()
            x_max = traj_coords[:, 0].max()
            y_min = traj_coords[:, 1].min()
            y_max = traj_coords[:, 1].max()

            #Determine the envelope wrt to the expansion_factor
            if kde_analysis_params.rast_output_params.expansion_factor > 1.0:
                dx = (x_max - x_min)*(kde_analysis_params.rast_output_params.expansion_factor - 1.0)/2.0
                dy = (y_max - y_min) * (kde_analysis_params.rast_output_params.expansion_factor - 1.0) / 2.0
                x_min -= dx
                x_max += dx
                y_min -= dy
                y_max += dy

            #Todo: align the origin point to some standard grid (e.g., to milliseconds of lat/lon grid, or to 50 m
            #ticks of UTM grid...

            # Determine the output raster size
            num_columns = math.ceil((x_max - x_min) / kde_analysis_params.rast_output_params.pixel_size)
            num_rows = math.ceil((y_max - y_min) / kde_analysis_params.rast_output_params.pixel_size)
            #print('Columns & Rows:', num_columns, num_rows)

            # Create the output raster file
            driver = gdal.GetDriverByName('HFA') #Use Erdas Imagine img format because Esri can read float64 from it
            output_raster = driver.Create(utf8_path=kde_analysis_params.rast_output_params.out_name,
                                        xsize=num_columns,
                                        ysize=num_rows,
                                        bands=1,
                                        eType=gdal.GDT_Float64)

            # Add the raster to the results object
            kde_analysis_result.out_rast = output_raster

            # Define the affine transform for converting between grid coordinates and map coordinates
            # needed by GDAL
            transform_vals=(x_min, kde_analysis_params.rast_output_params.pixel_size, 0,
                            y_max, 0, -kde_analysis_params.rast_output_params.pixel_size)
            output_raster.SetGeoTransform(transform_vals)

            #Get a hold of the raster output band
            outband = output_raster.GetRasterBand(1)

            # Set the NoData Value on the output band
            outband.SetNoDataValue(kde_analysis_params.rast_output_params.no_data_value)

            #Define the output_raster spatial reference

            output_raster.SetProjection(base.SRS.getSRS_from_EPSG
                                        (kde_analysis_params.rast_output_params.srs_epsg).ExportToWkt())

            # Define the affine transform to get grid pixel centroids as geographic coordinates and adjusting
            # the origin by a half pixel to the east and south from the grid origin point
            img_centroids_to_map = np.array(transform_vals).reshape(2, 3)
            img_centroids_to_map[0, 0] = x_min + kde_analysis_params.rast_output_params.pixel_size * 0.5
            img_centroids_to_map[1, 0] = y_max - kde_analysis_params.rast_output_params.pixel_size * 0.5

            # Create a blank grid array
            kdeGridArray = np.zeros(shape=(num_rows, num_columns), dtype=np.float64)

            # Loop over each pixel in the grid, transform the pixel coordinates (row, column) into
            # geographic coordinates (i.e., the centroid of the pixel). For each pixel, loop through the
            # relocation points and add the KDE density contribution to the pixel value.
            # ToDo: parallelize the calculation to run each pixel value independently
            it = np.nditer(kdeGridArray, flags=['multi_index'], op_flags=['readwrite'])
            while not it.finished:
                # Define the grid pixel coords:  [1, Pixel (column), Line (row)]
                pixel_coords = np.array([1, it.multi_index[1], it.multi_index[0]]).reshape(3, 1)

                # Get the current pixel centroid coordinates
                centroid = np.dot(img_centroids_to_map, pixel_coords).flatten()

                # Iterate through each point in the trajectory relocations
                for p in traj_coords:

                    # Determine the distance from the pixel centroid to the relocation point
                    distSq = math.pow(centroid[0]-p[0], 2) + math.pow(centroid[1]-p[1], 2)
                    if distSq <= maxDist:
                        theta = innerScalingConstant * math.exp(-distSq / variance)
                        it[0] += theta

                #Scale using the outerscalingconstant
                it[0] *= outerScalingConstant

                #Loop to the next pixel
                it.iternext()

            #Normalize the grid values
            kdeGridArray = kdeGridArray / kdeGridArray.sum()

            """
            Todo: Mask values less than the probability cut-off? Not sure if I want to port this
            from ArcMET...
            """

            # Write the Grid values to the output raster
            # kdeGridArrayReversed = kdeGridArray[::-1]
            outband.WriteArray(kdeGridArray)
            outband.FlushCache()

        except base.PymetException as e:
            kde_analysis_result.addError(e)


        #Return the analysis kde_analysis_result
        kde_analysis_result.AnalysisEnd = datetime.datetime.utcnow()
        return kde_analysis_params, kde_analysis_result #return both the analysis parameters and results


    @classmethod
    def Calc_hRef_SmoothingParameter(cls, x=np.array([]), y=np.array([])):
        varX = x.var()
        varY = y.var()
        var = math.sqrt(0.5 * (varX + varY))
        t = math.pow(len(x), -1.0 / 6.0)
        hRef = var * t # Source: Worton_1989
        return hRef






