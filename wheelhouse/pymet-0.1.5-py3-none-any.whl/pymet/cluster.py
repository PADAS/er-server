import pymet
import numpy as np

class Cluster:
    """A cluster represents a group of points in both time and space.
    Adds functionality to the base relocs object """

    def __init__(self, relocs=None):
        self._relocs = relocs or pymet.base.Relocations()

    @property
    def centroid(self):
        return self._relocs.centroid

    @property
    def relocs(self):
        return self._relocs

    def add_fix(self, fix):
        self._relocs.add_fix(fix)

    @property
    def cluster_radius(self):
        """ The cluster radius is the largest distance between a point in the relocs and the
        centroid of the relocs"""

        cluster_radius = 0.0
        centroid = self._relocs.centroid
        for pnt in self._relocs.get_fixes():
            #calculate the distance between the centroid and the fix
            this_radius = pnt.geopoint.dist_to_point(centroid)
            if this_radius > cluster_radius:
                cluster_radius = this_radius

        return cluster_radius

    @property
    def cluster_std_dev(self):
        """The cluster standard deviation is the standard deviation of the radii from the centroid
        to each point making up the cluster"""
        centroid = self._relocs.centroid
        radii = []
        for pnt in self._relocs.get_fixes():
            # calculate the distance between the centroid and the fix
            radii.append(pnt.geopoint.dist_to_point(centroid))
        return np.std(radii)

    def threshold_point_count(self, threshold_dist):
        """Counts the number of points in the cluster that are within a threshold distance of the geographic centre"""

        clust_count = 0
        centroid = self._relocs.centroid
        for pnt in self._relocs.get_fixes():
            # calculate the distance between the centroid and the fix
            this_radius = pnt.geopoint.dist_to_point(centroid)
            if this_radius <= threshold_dist:
                clust_count = clust_count + 1

        return clust_count
