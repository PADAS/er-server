import pymet.base
import datetime as dt
from osgeo import ogr

class VirtualFence:
    """
    A polyline geometry representing a virtual fenceline
    ogr_geometry: can be anything but geofencing works on the intersection of a line with the input geoemtry
    """
    def __init__(self, ogr_geometry=None, fence_name='', unique_id=''):
        self._ogr_geometry = ogr_geometry
        self._fence_name = fence_name
        self._unique_id = unique_id

    @property
    def name(self):
        return str(self._fence_name)

    @property
    def ogr_geometry(self):
        return self._ogr_geometry

    @property
    def unique_id(self):
        return self._unique_id


class GeofenceAnalysisParams(pymet.base.AnalysisParams):
    """
    A class to hold parameters needed for the geofence calculation.

    geofences: a list of geofences to run against each trajectory
    geofenceregions: a list of regions to test containment before/after a detected geofence crossing
    """

    def __init__(self, virtualfences=[], regions=[]):
        self._virtual_fences = virtualfences
        self._regions = regions

    @property
    def virtual_fences(self):
        return self._virtual_fences

    @property
    def regions(self):
        return self._regions


class GeofenceAnalysisResult(pymet.base.AnalysisResult):
    """ A class to hold the results of a geofence analysis"""

    def __init__(self, geofence_crossings=[]):
        self._geofence_crossings = geofence_crossings

    @property
    def geofence_crossings(self):
        return self._geofence_crossings

    def add_crossing(self, geofence_crossing):
        self._geofence_crossings.append(geofence_crossing)


class GeofenceCrossing:

    """ Class to store the result of a single geofence crossing"""

    def __init__(self, subject_ID='', subject_speed=0.0, subject_travel_heading=0.0,
                 estimated_cross_fix=None, virtual_fence_ID='', start_region_IDs = [], end_region_IDs = []):
        self._subject_id=subject_ID
        self._est_cross_fix = estimated_cross_fix
        self._start_region_ids = start_region_IDs
        self._end_region_ids = end_region_IDs
        self._virtual_fence_id = virtual_fence_ID
        self._subject_speed_kmhr = subject_speed
        self._subject_head = subject_travel_heading

    @property
    def subject_id(self):
        return self._subject_id

    @property
    def subject_speed_kmhr(self):
        return self._subject_speed_kmhr

    @property
    def subject_head(self):
        return self._subject_head

    @property
    def est_cross_fix(self):
        return self._est_cross_fix

    @property
    def start_region_ids(self):
        return self._start_region_ids

    @property
    def end_region_ids(self):
        return self._end_region_ids

    @property
    def virtual_fence_id(self):
        return self._virtual_fence_id


class GeofenceAnalysis:

    @classmethod
    def calc_crossings(cls, geofence_analysis_params, trajectories=None):
        """
        Run the crossings analysis using the input fences/regions against the various
        :param geofence_analysis_params:
        :param trajectories:
        :return:
        """

        trajectories = trajectories or []

        #Test to make sure the calculation parameters are not None and the correct type
        assert type(geofence_analysis_params) is GeofenceAnalysisParams

        #Create the output analysis result object
        result = GeofenceAnalysisResult()
        result.analysis_start = dt.datetime.utcnow() #Set the start time of the analysis

        for traj in trajectories:
            assert type(traj) is pymet.base.Trajectory

            subject_id = traj.relocs.subject_id
            trajsegs = traj.traj_segs

            for trajseg in trajsegs:
                fences = geofence_analysis_params.virtual_fences
                for fence in fences:
                    assert type(fence) is VirtualFence
                    # Attempt the intersection of the trajectory segment with the fence
                    intersectPnts = trajseg.ogr_geometry.Intersection(fence.ogr_geometry)

                    #intersectPnts can either be None, POINT, or MULTIPOINT
                    _intersectPnts = []
                    if intersectPnts.GetGeometryName() == 'POINT': #TODO better way to asses ogr geometry type?
                        _intersectPnts.append(intersectPnts)
                    else:
                        _intersectPnts = intersectPnts

                    for pnt in _intersectPnts:

                        #Create a GeoPoint at the crossing OGR point
                        crossing_geopoint = pymet.base.GeoPoint(x=pnt.GetX(), y=pnt.GetY())

                        segment_distance_to_crossing = \
                            trajseg.start_fix_geopoint.dist_to_point(pnt)

                        segment_length = trajseg.length_km

                        fractional_distance = 0.0
                        if segment_length > 0.0:
                            fractional_distance = segment_distance_to_crossing / segment_length

                        #Estimate the time of the break based on the fractional timespan
                        fractional_time = fractional_distance * \
                                 (trajseg.end_fix.fixtime - trajseg.start_fix.fixtime)
                        crossing_time = trajseg.start_fix.fixtime + fractional_time

                        #Create an estimated geofence cross fix
                        estimated_cross_fix = pymet.base.Fix(crossing_geopoint, crossing_time)

                        #Figure out the containment of the subject before and after the crossing
                        containment_before = GeofenceAnalysis.asses_containment(trajseg.start_fix_geopoint,
                                                                                geofence_analysis_params.regions)

                        containment_after = GeofenceAnalysis.asses_containment(trajseg.end_fix_geopoint,
                                                                               geofence_analysis_params.regions)

                        #Create the output fence crossing result
                        crossing = GeofenceCrossing(subject_id,
                                                    trajseg.speed_kmhr,
                                                    trajseg.heading,
                                                    estimated_cross_fix,
                                                    fence.unique_id,
                                                    containment_before,
                                                    containment_after)

                        result.add_crossing(crossing) #Add this given crossing to the result

        result.analysis_end = dt.datetime.utcnow()  # Set the end time of the analysis
        return result

    @classmethod
    def equator_fence(cls):
        """ Create a virtual fence around the equator that can be used for testing"""

        equatorFenceSeg = ogr.Geometry(type=ogr.wkbLineString)
        equatorFenceSeg.AssignSpatialReference(pymet.base.SRS.WGS84())
        equatorFenceSeg.AddPoint(0, 0, 0)
        equatorFenceSeg.AddPoint(90, 0, 0)
        equatorFenceSeg.AddPoint(180, 0, 0)
        equatorFenceSeg.AddPoint(270, 0, 0)
        equatorFenceSeg.AddPoint(0, 0, 0)

        #Wrap the Linestring into a Multilinestring for kicks
        equatorFence = ogr.Geometry(type=ogr.wkbMultiLineString)
        equatorFence.AssignSpatialReference(pymet.base.SRS.WGS84())
        equatorFence.AddGeometry(equatorFenceSeg)

        return equatorFence

    @classmethod
    def asses_containment(cls, geopoint, regions):
        """Pass back an array of all the regions IDs that contain the given geopoint"""
        containment = []

        if regions is None:
            return []

        for region in regions:
            assert type(region) is pymet.base.Region
            contains = region.ogr_geometry.Contains(geopoint.ogr_geometry)
            if contains is True:
                containment.append(region.unique_id)

        return containment



