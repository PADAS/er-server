import datetime
from geographiclib.geodesic import Geodesic
from osgeo import ogr
from osgeo import osr
from osgeo import gdal
import numpy as np
import geopandas as gpd
import pandas as pd
import shapely.geometry as shp

"""
References:

http://gdal.org/python/

GDAL/OGR http://www.gdal.org
http://pcjericks.github.io/py-gdalogr-cookbook/
"""


class SRS:

    @classmethod
    def get_WGS84(cls):
        srs = osr.SpatialReference()
        srs.ImportFromEPSG(4326)
        return srs

    @classmethod
    def getSRS_from_EPSG(cls, epsg=4326):
        srs = osr.SpatialReference()
        srs.ImportFromEPSG(epsg)
        return srs

class GeoPoint:
    """A geographic point is the most basic geometry"""

    def __init__(self, x=0, y=0, z=0):
        """Create a new point with the supplied geographic coordinates.
        Defaults to WGS84 SRS """

        self.point = ogr.Geometry(type=ogr.wkbPoint)
        self.srs_EPSG_Code = 4326
        srs = SRS.get_WGS84()
        self.point.AddPoint(x, y, z)
        self.point.AssignSpatialReference(srs)

    def getLongitude(self):
        """Shortcut to getting the X value"""
        return self.point.GetX()

    def getLatitude(self):
        """Shortcut to getting the Y value"""
        return self.point.GetY()

    def getOGRPoint(self):
        """ Return the ogr point """
        return self.point

    def get_SRS_EPSG_Code(self):
        """Return the spatial reference system EPSG code"""
        return self.srs_EPSG_Code

    def getMetersToOGRPoint(self, ogr_point):
        """Returns the distance in meters from this point to another ogr point geometry"""

        geod = Geodesic.WGS84
        great_circle = geod.Inverse(self.getOGRPoint().GetX(),
                                    self.getOGRPoint().GetY(),
                                    ogr_point.GetX(),
                                    ogr_point.GetY())
        return great_circle['s12']

    def __str__(self):
        return str(self.getOGRPoint())


class Fix:
    """A Fix is a temporal geopoint. Should probably inherit GeoPoint..."""

    def __init__(self, geopoint, fixtime):
        self.Fixtime = fixtime
        self.GeoPoint = geopoint

    def getFixtime(self):
        """ Return the fixtime"""
        return self.Fixtime

    def getGeoPoint(self):
        """Return the geopoint"""
        return self.GeoPoint

    def getOGRPoint(self):
        """A shortcut for returning the ogr point geometry from the geopoint"""
        return self.getGeoPoint().getOGRPoint()


class Relocations:
    """Relocations is a model for a set of fixes from a given subject. Because fixes are temporal, they can be ordered
    asc or desc"""

    def __init__(self, fixes=[], subject_id=''):
        if fixes is None:
            fixes = []
        self.fixes = fixes
        self.subject_id = subject_id

    def getTimespanSeconds(self):
        """Returns the total time between start and end times in seconds"""

        if len(self.fixes) > 0:
            earliest_fixtime = self.getEarliestFix().getFixtime()
            latest_fixtime = self.getLatestFix().getFixtime()

            if (earliest_fixtime is not None) and (latest_fixtime is not None):
                ts = latest_fixtime - earliest_fixtime
                return ts.total_seconds()
        else:
            return 0

    def getSubjectID(self):
        return self.subject_id

    def getDisplacementSegment(self):
        """Return the straight line segment between the earliest and latest fix in the fixes array """

        if (self.getEarliestFix() is not None) and (self.getLatestFix() is not None):
            return StraightTrackSeg(self.getEarliestFix(), self.getLatestFix())
        else:
            return None

    def getFixCount(self):
        """ fixes array length"""

        if self.fixes is not None:
            return len(self.fixes)
        else:
            return 0

    def getFixes(self, temporal_order='ASC'):
        """Instance method to access the fixes array sorted in either chronologically asc or desc order"""
        if temporal_order == 'DESC':
            return sorted(self.fixes,key=lambda fix: fix.getFixtime(), reversed=True)
        else:
            return sorted(self.fixes,key=lambda fix: fix.getFixtime())

    def get_Geopandas_series(self, temporal_order='ASC'):
        """Method to access the fixes array sorted in either chronologically asc or desc order as a
        GeoPandas series. This creates a copy of the underlying fixes array so will suck memory. Because
        the fixtimes are used as the index, they have to be unique or this would fail. """
        gs = gpd.GeoSeries([shp.Point((p.getOGRPoint().GetX(),p.getOGRPoint().GetY()))
                            for p in self.getFixes(temporal_order)],
                            index=[p.getFixtime() for p in self.getFixes(temporal_order)])
        gs.crs = {'init':'epsg:4326'}
        return gs

    def get_Pandas_series(self, temporal_order='ASC'):
        """return a Geopandas Series containing the x,y coordinate of each point"""
        xy_s = pd.Series([(p.getOGRPoint().GetX(), p.getOGRPoint().GetY()) for p in self.getFixes(temporal_order)],
                       index=[p.getFixtime() for p in self.getFixes(temporal_order)])
        return xy_s

    def get_Numpy_array(self, temporal_order='ASC'):
        """return a numpy array containing the x,y coordinate of each point"""
        xy_s = np.array([[p.getOGRPoint().GetX(), p.getOGRPoint().GetY()] for p in self.getFixes(temporal_order)])
        #Could also combine x, and y vectors using: np.vstack([x,y]).T
        return xy_s

    def addFix(self, fix):
        """ Add a fix to the fixes array"""
        self.fixes.append(fix)

    def getEarliestFix(self):
        """ Return the earliest fix from the fixes array"""
        if self.getFixCount() > 0:
            return self.getFixes()[0]
        else:
            return None

    def getLatestFix(self):
        """ Return the latest fix from the fixes array"""
        if self.getFixCount() > 0:
            return self.getFixes()[-1]
        else:
            return None

    def getOGRMultiPointGeometry(self):
        """Return the ogr multipoint geometry of the relocation fixes"""
        pnts = ogr.Geometry(type=ogr.wkbMultiPoint)
        pnts.AssignSpatialReference(SRS.get_WGS84())
        for pnt in self.getFixes():
            pnts.AddGeometry(pnt.getOGRPoint())
        return pnts

    def getGeometricCentroidOGRPoint(self):
        """ Return the centroid of the fixes in the relocations fix array"""

        centroid = self.getOGRMultiPointGeometry().Centroid()
        centroid.AssignSpatialReference(SRS.get_WGS84())
        return centroid


class StraightTrackSeg(object):
    """Class representing the straight line geometry between start and end point"""

    def __init__(self, start_fix, end_fix):
        self.start_fix = start_fix
        self.end_fix = end_fix
        if (self.start_fix.getGeoPoint() is None) or (self.end_fix.getGeoPoint() is None):
            self.line = None

        # Build the line geometry
        self.line = ogr.Geometry(type=ogr.wkbLineString)
        self.line.AddPoint(self.start_fix.getOGRPoint().GetX(),
                           self.start_fix.getOGRPoint().GetY(),
                           self.start_fix.getOGRPoint().GetZ())
        self.line.AddPoint(self.end_fix.getOGRPoint().GetX(),
                           self.end_fix.getOGRPoint().GetY(),
                           self.end_fix.getOGRPoint().GetZ())

        # Build the line Spatial Reference System
        self.line.AssignSpatialReference(SRS.get_WGS84())
        self.srsEPSGCode = 4326

    def getOGRLineGeometry(self):
        return self.line

    def getStartFixOGRGeometry(self):
        return self.start_fix.getOGRPoint()

    def getEndFixOGRGeometry(self):
        return self.end_fix.getOGRPoint()

    def getStartFixGeoPoint(self):
        return self.start_fix.getGeoPoint()

    def getEndFixGeoPoint(self):
        return self.end_fix.getGeoPoint()

    def getStartFix(self):
        return self.start_fix

    def getEndFix(self):
        return self.end_fix

    def getMidPointTime(self):
        pass  # To-do: return the mid-way time between start and end

    def getTotalTime(self):
        """Returns the total time between start and end times in seconds"""
        if (self.end_fix.getFixtime() is not None) and (self.start_fix.getFixtime() is not None):
            ts = self.end_fix.getFixtime() - self.start_fix.getFixtime()
            return ts.total_seconds()
        else:
            return 0

    def getSpeed(self):
        """Returns the straight-line (average) speed traveled between start and end fixes"""
        if self.getTotalTime() != 0:
            return (self.getLength() / 1000) / (self.getTotalTime() / 3600)  # Km/Hr

    def getHeading(self):
        """ Returns the  the compass heading of the segment WRT True North """
        geod = Geodesic.WGS84
        great_circle = geod.Inverse(self.start_fix.getOGRPoint().GetX(),
                                    self.start_fix.getOGRPoint().GetY(),
                                    self.end_fix.getOGRPoint().GetX(),
                                    self.end_fix.getOGRPoint().GetY())
        azimuth = great_circle['azi1']
        if azimuth < 0:
            azimuth += 360
        return azimuth

    def getLength(self):
        """Returns the distance between point 1 & 2 in meters"""

        geod = Geodesic.WGS84
        great_circle = geod.Inverse(self.start_fix.getOGRPoint().GetX(),
                                    self.start_fix.getOGRPoint().GetY(),
                                    self.end_fix.getOGRPoint().GetX(),
                                    self.end_fix.getOGRPoint().GetY())
        return great_circle['s12']


class TrajectorySegFilter:
    """Class filtering a set of trajectory segment segments"""

    def __init__(self, min_length_meters=0.0, max_length_meters=-1.0, min_time_secs=0.0,
                 max_time_secs=-1.0, min_speed_kmhr=0.0, max_speed_kmhr=-1.0):
        self._min_length_meters = min_length_meters  # the minimum length in meters that a trackseg can be
        self._max_length_meters = max_length_meters  # the maximum length in meters that a trackseg can be (Nullable)
        self._min_time_secs = min_time_secs  # the minimum time in seconds that a trackseg can be
        self._max_time_secs = max_time_secs  # the maximum time in seconds that a trackseg can be
        self._min_speed_kmhr = min_speed_kmhr  # the minimum speed in KM/Hr that a trackseg can be
        self._max_speed_kmhr = max_speed_kmhr  # the maximum speed in Km/Hr that a trackseg can be

    @property
    def min_length_meters(self):
        return self._min_length_meters

    @property
    def max_length_meters(self):
        return self._max_length_meters

    @property
    def min_time_secs(self):
        return self._min_time_secs

    @property
    def max_time_secs(self):
        return self._max_time_secs

    @property
    def min_speed_kmhr(self):
        return self._min_speed_kmhr

    @property
    def max_speed_kmhr(self):
        return self._max_speed_kmhr


class Trajectory:
    """A trajectory is a collection of relocations. Can have both point series and a
    track segment series representations"""

    def __init__(self, relocations, TrajectorySegmentFilter=None):
        self.relocations = relocations
        self._TrajectorySegmentFilter = TrajectorySegmentFilter

    def getRelocations(self):
        """Return the relocations that make up the trajectory"""

        return self.relocations

    def getRelocationsFixCount(self):
        """Shortcut to the relocations fixes array length"""

        if self.relocations is not None:
            return self.relocations.getFixCount()
        else:
            return 0

    @property
    def TrajectorySegmentFilter(self):
        return self._TrajectorySegmentFilter

    @TrajectorySegmentFilter.setter
    def TrajectorySegmentFilter(self, value):
        assert type(value) is TrajectorySegFilter
        self._TrajectorySegmentFilter = value

    #TODO add functionality for filtering
    def getTrajectorySegments(self):
        """Turn the trajectory into a list of tracksegments subject to the filter"""

        trajSegments = []
        relocsLen = len(self.relocations.fixes)
        if relocsLen > 1:
            for i in range(1, relocsLen):
                trajSeg = StraightTrackSeg(self.relocations.getFixes()[i - 1], self.relocations.getFixes()[i])
                if self.TrajectorySegmentFilter is not None:
                    if (trajSeg.getLength() > self.TrajectorySegmentFilter.min_length_meters) and \
                            (trajSeg.getLength() < self.TrajectorySegmentFilter.max_length_meters) and \
                            (trajSeg.getTotalTime() > self.TrajectorySegmentFilter.min_time_secs) and \
                            (trajSeg.getTotalTime() < self.TrajectorySegmentFilter.max_time_secs) and \
                            (trajSeg.getSpeed() > self.TrajectorySegmentFilter.min_speed_kmhr) and \
                            (trajSeg.getSpeed() < self.TrajectorySegmentFilter.max_speed_kmhr):
                        trajSegments.append(trajSeg)
                else:
                    trajSegments.append(trajSeg)
        return trajSegments

    def getTrajectorySegmentsCount(self):
        """A shortcut to getting the length of the trajectory segments array"""

        trajSegments = self.getTrajectorySegments()
        if trajSegments is not None:
            return len(trajSegments)
        else:
            return 0

    #TODO add functionality for filtering
    def getTortuosity(self):
        pass

    # TODO add functionality for filtering
    def getTotalDistanceMeters(self):
        pass

    # TODO add functionality for filtering
    def resample(self):
        pass

    # TODO add functionality for filtering
    def getOGRMultilinestringGeometry(self):
        # Create an OGR multistring object

        polyline = ogr.Geometry(ogr.wkbMultiLineString)
        polyline.AssignSpatialReference(SRS.get_WGS84())

        for seg in self.getTrajectorySegments():
            segGeo = seg.getOGRLineGeometry()
            if segGeo is not None:
                polyline.AddGeometry(segGeo)
        return polyline


class AnalysisParams:
    """ An abstract class that acts as a container for calculation parameters"""
    pass


class AnalysisResult:
    """An abstract class to act as a container for calculation results"""

    def __init__(self):
        self._analysis_start = datetime.datetime.utcnow()
        self._analysis_end = datetime.datetime.utcnow()
        self._errors = []

    @property
    def AnalysisStart(self):
        return self._analysis_start

    @AnalysisStart.setter
    def AnalysisStart(self, value):
        if type(value) is datetime.datetime:
            self._analysis_start = value

    @property
    def AnalysisEnd(self):
        return self._analysis_end

    @AnalysisEnd.setter
    def AnalysisEnd(self, value):
        if type(value) is datetime.datetime:
            self._analysis_end = value

    @property
    def Errors(self):
        return self._errors

    def addError(self, value):
        self._errors.append(value)


class Region:
    """
    A polygon with an associated name. Becomes a useful construct in several pymet calculations
    """

    def __init__(self, ogr_geometry=None, region_name='', unique_ID=''):
        self.ogr_geometry=ogr_geometry
        self.region_name=region_name
        self.unique_ID = unique_ID

    def getName(self):
        return str(self.region_name)

    def getUniqueID(self):
        return self.unique_ID

    def getOGRGeometry(self):
        return self.ogr_geometry


class RasterOutputParams:
    """ A class for holding raster output parameters"""

    def __init__(self, pixel_size=500.0,
                 out_name='pymet_rast.img', srs_epsg=4326, no_data_value=0.0, expansion_factor=1.0):
        self._pixel_size = pixel_size
        self._out_name = out_name
        self._srs_epsg = srs_epsg
        self._no_data_value = no_data_value
        self._expansion_factor = expansion_factor

    @property
    def pixel_size(self):
        return self._pixel_size

    @property
    def out_name(self):
        return self._out_name

    @property
    def srs_epsg(self):
        return self._srs_epsg

    @property
    def no_data_value(self):
        return self._no_data_value

    @property
    def expansion_factor(self):
        return self._expansion_factor


class RasterEngine:
    """
    A class with functions for working with raster data
    """

    # Meter to Decimal Degree Conversion
    # Based on an average earth radius of 6367516.477 from WGS84 Datum
    one_meter_in_DD = (180.0 / (6367516.477 * np.pi))

    @classmethod
    def createRandomImageArray(cls, cols, rows):
        return np.array([np.random.random_integers(0, 255, cols) for x in range(0, rows - 1)])

    @classmethod
    def createBlankRasterFromGeometry(cls, ingeo, pixel_size, no_data_value, out_rast):

        #Determine the extent of the input geometry
        env = ingeo.GetEnvelope()
        x_min, x_max, y_min, y_max = env[0], env[1], env[2], env[3]
        #print(pixel_size)
        #print(x_min, x_max, y_min, y_max)
        
        # Determine the output raster size
        num_columns = int((x_max - x_min) / pixel_size) #Calculate number of image columns
        num_rows = int((y_max - y_min) / pixel_size) # Calculate number of image rows
        #print(num_columns, num_rows)

        #Create the raster file
        driver = gdal.GetDriverByName('GTiff')
        target_ds = driver.Create(out_rast, num_columns, num_rows, gdal.GDT_Byte)

        #Define the affine transform for converting between image coordinates and map coordinates
        target_ds.SetGeoTransform((x_min, pixel_size, 0, y_max, 0, -pixel_size))
        
        #Set the band values
        band = target_ds.GetRasterBand(1)
        band.SetNoDataValue(no_data_value)
        
        #Set the output spatial reference
        target_ds.SetProjection(SRS.get_WGS84().ExportToWkt())

        array = RasterEngine.createRandomImageArray(num_columns, num_rows)
        print(array)
        reversed_arr = array[::-1]
        band.WriteArray(reversed_arr)
        band.FlushCache()

    @classmethod
    def rasterizeVectorDataset(cls,vector_fn, pixel_size, NoData_value, raster_fn):
        # Open the data source and read in the extent

        source_ds = ogr.Open(vector_fn)
        source_layer = source_ds.GetLayer()
        x_min, x_max, y_min, y_max = source_layer.GetExtent()
        print(x_min, x_max, y_min, y_max)

        # Create the destination data source
        x_res = int((x_max - x_min) / pixel_size)
        y_res = int((y_max - y_min) / pixel_size)
        target_ds = gdal.GetDriverByName('GTiff').Create(raster_fn, x_res, y_res, 1, gdal.GDT_Byte)
        target_ds.SetGeoTransform((x_min, pixel_size, 0, y_max, 0, -pixel_size))
        band = target_ds.GetRasterBand(1)
        band.SetNoDataValue(NoData_value)

        # Rasterize
        gdal.RasterizeLayer(target_ds, [1], source_layer, burn_values=[1])

class PymetException(Exception):
    """ A custom exception type for pymet specific errors"""
    pass