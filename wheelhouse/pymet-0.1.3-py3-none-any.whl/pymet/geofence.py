import pymet.base
import datetime
from osgeo import ogr

class VirtualFence:
    """
    A polyline geometry representing a virtual fenceline
    ogr_geometry: can be anything but geofencing works on the intersection of a line with the input geoemtry
    """
    def __init__(self, ogr_geometry=None, fence_name='', unique_id=''):
        self.ogr_geometry = ogr_geometry
        self.fence_name = fence_name
        self.unique_id = unique_id

    def getName(self):
        return str(self.fence_name)

    def getOGRGeometry(self):
        return self.ogr_geometry

    def getUniqueID(self):
        return self.unique_id


class GeofenceAnalysisParams(pymet.base.AnalysisParams):
    """
    A class to hold parameters needed for the geofence calculation.

    geofences: a list of geofences to run against each trajectory
    geofenceregions: a list of regions to test containment before/after a detected geofence crossing
    """

    def __init__(self, virtualfences=[], regions=[]):
        self.virtualfences = virtualfences
        self.regions = regions

    def getVirtualfences(self):
        return self.virtualfences

    def getRegions(self):
        return self.regions


class GeofenceAnalysisResult(pymet.base.AnalysisResult):
    """ A class to hold the results of a geofence analysis"""

    def __init__(self, geofence_crossings=[]):
        self.geofence_crossings = geofence_crossings

    def getGeofenceCrossings(self):
        return self.geofence_crossings

    def addCrossing(self, geofence_crossing):
        self.geofence_crossings.append(geofence_crossing)


class GeofenceCrossing:

    """ Class to store the result of a single geofence crossing"""

    def __init__(self, subject_ID='', subject_speed = 0.0, subject_travel_heading=0.0,
                 estimated_cross_fix=None, virtual_fence_ID='', start_region_IDs = [], end_region_IDs = []):
        self.subject_ID=subject_ID
        self.estimated_cross_fix = estimated_cross_fix
        self.start_region_IDs = start_region_IDs
        self.end_region_IDs = end_region_IDs
        self.virtual_fence_ID = virtual_fence_ID
        self.subject_speed = subject_speed
        self.subject_travel_heading = subject_travel_heading

    def getSubjectID(self):
        return self.subject_ID

    def getSubjectSpeed(self):
        return self.subject_speed

    def getSubjectTravelHeading(self):
        return  self.subject_travel_heading

    def getEstimatedCrossFix(self):
        return self.estimated_cross_fix

    def getStartRegionIDs(self):
        return self.start_region_IDs

    def getEndRegionIDs(self):
        return self.end_region_IDs

    def getVirtualFenceID(self):
        return self.virtual_fence_ID


class GeofenceAnalysis:

    @classmethod
    def calculateGeofenceCrossings(cls, geofence_analysis_params, trajectories=None):
        """
        Run the crossings analysis using the input fences/regions against the various
        :param geofence_analysis_params:
        :param trajectories:
        :return:
        """

        trajectories = trajectories or []

        #Test to make sure the calculation parameters are not None and the correct type
        assert type(geofence_analysis_params) is GeofenceAnalysisParams

        #Create the output analysis result object
        result = GeofenceAnalysisResult()
        result.AnalysisStart = datetime.datetime.utcnow() #Set the start time of the analysis

        for traj in trajectories:
            assert type(traj) is pymet.base.Trajectory

            subject_id = traj.getRelocations().getSubjectID()
            trajsegs = traj.getTrajectorySegments()

            for trajseg in trajsegs:
                fences = geofence_analysis_params.getVirtualfences()
                for fence in fences:
                    assert type(fence) is VirtualFence
                    # Attempt the intersection of the trajectory segment with the fence
                    intersectPnts = trajseg.getOGRLineGeometry().Intersection(fence.getOGRGeometry())

                    #intersectPnts can either be None, POINT, or MULTIPOINT
                    _intersectPnts = []
                    if intersectPnts.GetGeometryName() == 'POINT': #TODO better way to asses ogr geometry type?
                        _intersectPnts.append(intersectPnts)
                    else:
                        _intersectPnts = intersectPnts

                    for pnt in _intersectPnts:

                        #Create a GeoPoint at the crossing OGR point
                        crossing_geopoint = pymet.base.GeoPoint(x=pnt.GetX(), y=pnt.GetY())

                        segment_distance_to_crossing = \
                            trajseg.getStartFixGeoPoint().getMetersToOGRPoint(pnt)

                        segment_length = trajseg.getLength()

                        fractional_distance = 0.0
                        if segment_length > 0.0:
                            fractional_distance = segment_distance_to_crossing / segment_length

                        #Estimate the time of the break based on the fractional timespan
                        fractional_time = fractional_distance * \
                                 (trajseg.getEndFix().getFixtime() - trajseg.getStartFix().getFixtime())
                        crossing_time = trajseg.getStartFix().getFixtime() + fractional_time

                        #Create an estimated geofence cross fix
                        estimated_cross_fix = pymet.base.Fix(crossing_geopoint, crossing_time)

                        #Figure out the containment of the subject before and after the crossing
                        containment_before = GeofenceAnalysis.asses_containment(trajseg.getStartFixGeoPoint(),
                                                                                geofence_analysis_params.getRegions())

                        containment_after = GeofenceAnalysis.asses_containment(trajseg.getEndFixGeoPoint(),
                                                                               geofence_analysis_params.getRegions())

                        #Create the output fence crossing result
                        crossing = GeofenceCrossing(subject_id,
                                                    trajseg.getSpeed(),
                                                    trajseg.getHeading(),
                                                    estimated_cross_fix,
                                                    fence.getUniqueID(),
                                                    containment_before,
                                                    containment_after)

                        result.addCrossing(crossing) #Add this given crossing to the result

        result.AnalysisEnd = datetime.datetime.utcnow()  # Set the end time of the analysis
        return result

    @classmethod
    def getEquatorFence(cls):
        """ Create a virtual fence around the equator that can be used for testing"""

        equatorFenceSeg = ogr.Geometry(type=ogr.wkbLineString)
        equatorFenceSeg.AssignSpatialReference(pymet.base.SRS.get_WGS84())
        equatorFenceSeg.AddPoint(0, 0, 0)
        equatorFenceSeg.AddPoint(90, 0, 0)
        equatorFenceSeg.AddPoint(180, 0, 0)
        equatorFenceSeg.AddPoint(270, 0, 0)
        equatorFenceSeg.AddPoint(0, 0, 0)

        #Wrap the Linestring into a Multilinestring for kicks
        equatorFence = ogr.Geometry(type=ogr.wkbMultiLineString)
        equatorFence.AssignSpatialReference(pymet.base.SRS.get_WGS84())
        equatorFence.AddGeometry(equatorFenceSeg)

        return equatorFence

    @classmethod
    def asses_containment(cls, geopoint, regions):
        """Pass back an array of all the regions IDs that contain the given geopoint"""
        containment=[]

        if regions is None:
            return []

        for region in regions:
            assert type(region) is pymet.base.Region
            contains = region.getOGRGeometry().Contains(geopoint.getOGRPoint())
            if contains is True:
                containment.append(region.getUniqueID())

        return containment



