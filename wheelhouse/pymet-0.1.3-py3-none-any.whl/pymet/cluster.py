import pymet
import numpy as np

class Cluster:
    """A cluster represents a group of points in both time and space.
    Adds functionality to the base relocations object """

    def __init__(self, relocs=pymet.base.Relocations()):
        self.relocations = relocs

    def getRelocations(self):
        return self.relocations

    def addFix(self, fix):
        self.relocations.addFix(fix)

    def getCentroidOGRPoint(self):
        return self.relocations.getGeometricCentroidOGRPoint()

    def getClusterRadius(self):
        """ The cluster radius is the largest distance between a point in the relocations and the
        centroid of the relocations"""

        cluster_radius = 0.0
        centroid = self.relocations.getGeometricCentroidOGRPoint()
        for pnt in self.relocations.getFixes():
            #calculate the distance between the centroid and the fix
            this_radius = pnt.getGeoPoint().getMetersToOGRPoint(centroid)
            if this_radius > cluster_radius:
                cluster_radius = this_radius

        return cluster_radius

    def NumPointsWithinThreshold(self, threshold_dist):
        """Counts the number of points in the cluster that are within a threshold distance of the geographic centre"""

        clust_count = 0
        centroid = self.relocations.getGeometricCentroidOGRPoint()
        for pnt in self.relocations.getFixes():
            # calculate the distance between the centroid and the fix
            this_radius = pnt.getGeoPoint().getMetersToOGRPoint(centroid)
            if this_radius <= threshold_dist:
                clust_count = clust_count + 1

        return clust_count
